# SDK

Módulo reservado para versões futuras. Sem implementação na v0.1.0.
