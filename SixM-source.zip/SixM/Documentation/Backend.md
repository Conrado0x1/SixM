# SixM Master — backend e autenticação

Esta é a primeira etapa funcional dos sistemas internos solicitada após o launcher compilado. O serviço C# é separado da UI C++ e não depende do jogo. Não foi ligado a nenhum fornecedor cloud nem publicado na Internet.

## Componentes

- `Master/SixM.Master/Program.cs`: configuração, limites de pedidos, middleware de segurança, health checks e arranque.
- `Data/AuthDbContext.cs`: ASP.NET Core Identity e tabela `auth_sessions` em PostgreSQL.
- `Data/Migrations/`: schema versionado, gerado pelo EF Core.
- `Auth/AuthEndpoints.cs`: registo, login, refresh, logout, logout global e perfil.
- `Auth/SessionAuthenticationHandler.cs`: validação de bearer tokens contra o estado persistido.
- `Auth/TokenCodec.cs`: geração criptográfica de tokens e hash SHA-256.

Passwords são processadas pelo PasswordHasher do ASP.NET Core Identity. Não existe criptografia de passwords reversível nem um algoritmo de password inventado para o projeto. O serviço não é um servidor OAuth/OIDC.

## Ciclo de uma sessão

1. O registo valida email, display name e política de password. A conta tem `emailConfirmed=false` nesta etapa.
2. O login valida a password através do Identity e aplica lockout. São criados dois tokens aleatórios independentes de 256 bits.
3. A base de dados guarda apenas os hashes dos tokens, IDs e datas. O cliente recebe o access token e o refresh token uma única vez nessa resposta.
4. Cada pedido protegido procura a sessão pelo hash do access token e valida ambos os prazos.
5. O refresh substitui os dois hashes e incrementa uma versão com controlo de concorrência. Um refresh antigo não pode voltar a ser usado. A expiração absoluta de sete dias não é prolongada.
6. O logout elimina a sessão; os pedidos seguintes deixam de ser autorizados. O logout global revoga todas as sessões desse utilizador.

Uma renovação próxima do fim da sessão limita a validade do access token ao prazo absoluto restante. Uma autorização em curso antes de um logout pode terminar; não se promete cancelar retroativamente pedidos já autorizados.

## Base de dados local preparada

Foi criada uma instância PostgreSQL **18.7** em `work/PostgreSQL`, com dados em `work/pgdata`, ligada apenas a `127.0.0.1:55432`. Existem bases separadas `sixm_development` e `sixm_auth_tests`, com um role de aplicação sem privilégios de superuser. As credenciais geradas estão apenas em `work/backend-private.json`, fora dos artefactos e do código GitHub. Não imprimir esse ficheiro em logs.

Nesta máquina:

```powershell
.\Master\Start-Local.ps1 -UseWorkspaceConfiguration -Migrate
.\Master\Start-Local.ps1 -UseWorkspaceConfiguration
```

O script usa o SDK .NET 10 preparado localmente, se disponível. Noutra máquina, instalar .NET SDK 10 e PostgreSQL e fornecer `ConnectionStrings__SixM`; ver [Master](../Master/README.md). Os binários PostgreSQL e o SDK são ferramentas de desenvolvimento e não fazem parte do ZIP do código.

## Testes reproduzíveis

Executar numa base dedicada chamada `sixm_auth_tests`, nunca numa base de produção. Configurar privadamente `ConnectionStrings__SixM`, `PGHOST`, `PGPORT`, `PGDATABASE=sixm_auth_tests`, `PGUSER`, `PGPASSWORD` e `SIXM_TEST_PSQL` (caminho para psql).

```powershell
python .\Tests\RunMasterIntegration.py --dotnet dotnet --report-dir .\work\master-tests
```

O runner restaura as versões bloqueadas, compila, aplica migrations, inicia uma API própria em loopback, testa o bloqueio do ambiente Production e executa nove testes reais: persistência após reinício; validação de registo; rejeição de credenciais inválidas; rotação e logout; refresh concorrente; lockout; logout global; expiração e armazenamento apenas de hashes; rate limiting. Encerra apenas o processo de API que criou. As contas de teste usam endereços únicos `example.invalid`.

## Resultado desta entrega

.NET SDK **10.0.404**, ASP.NET Core/Identity/EF Core **10.0.15**, provider Npgsql EF Core **10.0.4**, PostgreSQL **18.7**. Build Release: **0 avisos, 0 erros**. Integração: **9 testes aprovados, 0 ignorados**. Arranque em Production rejeitado conforme a restrição desta etapa. Relatórios em `Reports/`.

## Limites e próxima ligação

O launcher v0.1.1 liga-se à API com Qt Network e permite registo, login, perfil, renovação e logout em Settings. O indicador superior verifica `/health/ready` a cada dez segundos. Não guarda passwords ou tokens em QSettings: a sessão do cliente permanece em memória e é necessário voltar a entrar depois de fechar o launcher. Persistência através do cofre do Windows é uma etapa futura. O botão Link account continua removido.

O cliente aceita HTTP apenas para loopback, exige HTTPS para endpoints remotos, mantém a validação TLS padrão e não segue redirects de autenticação. Esta entrega usa o endpoint local de desenvolvimento. Testes adicionais do cliente verificam API indisponível, rejeição de HTTP remoto e o percurso real através dos widgets Qt.

Antes de uma disponibilização pública faltam confirmação de email, recuperação de conta, MFA, processos de operação e auditoria do deployment. Não há mailer falso, OAuth simulado ou recuperação de password que finja enviar emails. O serviço recusa arrancar fora de Development. Esta etapa não implementa servidores multiplayer, scripting ou integração com GTA VI.

## Referências

- [ASP.NET Core Identity](https://learn.microsoft.com/en-us/aspnet/core/security/authentication/identity?view=aspnetcore-10.0)
- [Npgsql / EF Core PostgreSQL](https://www.npgsql.org/efcore/)
- [PostgreSQL Windows](https://www.postgresql.org/download/windows/)
- [Licença dos ícones Lucide](https://lucide.dev/license)
