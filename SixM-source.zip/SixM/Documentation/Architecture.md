# Arquitetura v0.1.1

`main.cpp` configura QApplication e executa três tarefas de bootstrap através do event loop. `SplashScreen` apresenta o progresso dessas tarefas locais antes da abertura do launcher. `MainWindow` compõe o shell e as páginas num QStackedWidget. `NavigationBar` gere a navegação horizontal e os controlos da janela; substitui a sidebar da proposta anterior por pedido do utilizador. `Dashboard` compõe os cartões e emite pedidos de navegação. `HeroBanner` desenha a imagem fornecida com overlay. `AppSettings` encapsula QSettings e valida a existência da pasta antes de gravar. A propriedade dos objetos Qt segue a árvore de parents; a janela principal tem ownership explícito via unique_ptr no bootstrap.

A interface sem moldura mantém minimizar, maximizar/restaurar, fechar, arrastar pelo topo e redimensionar pelas margens usando o hit testing nativo do Windows. Os servidores e as contagens no destaque são exemplos identificados como DEMO; a coluna de novidades apresenta texto local sobre o projeto, sem fingir um feed remoto.

Os recursos visuais ficam embebidos via Qt Resource System, sem depender do diretório de trabalho. O binário tem metadados Windows e ícone. DLLs Qt são ligadas dinamicamente. Dependências runtime: Qt Core, Gui e Widgets, plugins Windows e runtime MSVC. Qt Test é apenas dependência dos testes.

## Limites e evolução

O backend C# fornece identidade e sessões. `MasterClient` encapsula chamadas HTTP ao serviço, verificações de disponibilidade e tokens em memória; `AccountWidget` fornece os formulários em Settings. Isto não implementa o protocolo multiplayer ou integração com o jogo. A navegação permite inspecionar os estados futuros do server browser. Não existem certificados de assinatura, chaves ou endpoints inventados.

O cliente usa a validação TLS padrão para HTTPS e limita HTTP a loopback. A autenticação de desenvolvimento já foi ligada à UI. Configuração TLS de produção, verificação de emails, recuperação de contas, integridade de conteúdo e updates assinados continuam a exigir as etapas respetivas. C++ não impede análise nem modificação do executável.

## Roadmap — objetivos, sujeitos a investigação

| Versão | Objetivo |
| --- | --- |
| 0.1.0 | Launcher Foundation — esta entrega |
| 0.2.0 | Interface e navegação alargadas |
| 0.3.0 | Server Browser |
| 0.4.0 | Networking |
| 0.5.0 | Server Core |
| 0.6.0 | Player Management |
| 0.7.0 | Resource System |
| 0.8.0 | Lua Runtime |
| 0.9.0 | Investigação da integração GTA VI |
| 1.0.0 | Primeiro multiplayer, condicionado à viabilidade |

A integração será investigada separadamente sem distribuir ficheiros proprietários, contornar proteções ou assumir uma API pública/versão PC disponível. Nenhum dos milestones futuros está implementado nesta entrega.
