# Ambiente e validação — 25 novembro 2026

## Visual Studio 2022

Detetado Visual Studio Community 2022, 17.13.5, em `C:\Program Files\Microsoft Visual Studio\2022\Community`. A instalação existente não fornece uma toolchain C++ completa: faltam headers e Windows SDK, e o CMake não reconhece a instância como utilizável. Não foi apresentada como pronta nem reparada globalmente.

## MSVC

Preparada uma toolchain local de MSVC 2022 v143: compilador **19.43.34810**, ferramentas em `work/msvc/VC/Tools/MSVC/14.43.34808`. Windows SDK **10.0.22621.0**. Os pacotes foram obtidos dos servidores Microsoft usando o script portable-msvc, com validação SHA-256 dos payloads. O script original foi inspecionado antes da execução. Referência: https://gist.github.com/mmozeiko/7f3162ec2988e81e56d5c4e22cde9977 .

## Qt 6 e kit MSVC 2022 x64

Instalado **Qt 6.8.3 / msvc2022_64**, arquivos qtbase e qttools, em `work/Qt/6.8.3/msvc2022_64`. `qmake -query QT_VERSION` devolveu 6.8.3. Não foi necessário instalar Qt Creator. Os módulos runtime usados são Core, Gui e Widgets; Test é usado apenas nos testes.

## CMake

Instalado **CMake 4.4.5** no ambiente Python local `work/tooling`. A compilação desta máquina usa o generator **NMake Makefiles**, porque a instalação global incompleta de Visual Studio não permite usar o generator VS 2022. Os presets VS 2022 são fornecidos para máquinas com o workload C++ completo.

## Git

Confirmado Git **2.54.0.windows.1**. Código inicializado num repositório local, sem remoto, publicação ou identidade de autor inventada.

## Compilação

C++20, MSVC x64, configuração Release. Build completo e CTest aprovados. Não existem erros de compilação conhecidos. O aviso opcional sobre Vulkan não afeta esta aplicação Qt Widgets raster; não foi acrescentada uma dependência de Vulkan. As traduções Qt não foram instaladas: a interface desta entrega é inglesa.

## Testes automatizados

Suite Qt Test: recursos PNG/logo embebidos; navegação e estado offline; conexão indisponível; History sem sessões; rejeição de pasta inexistente; persistência em configuração temporária isolada; progresso das tarefas de arranque; renderização a 1440×900 e 1200×780. Contagem: 7 resultados aprovados incluindo init/cleanup.

CTest contém também `launcher-startup`: executa `SixM.exe --startup-check` e verifica que o bootstrap completo termina com sucesso. A execução com o plugin Windows foi verificada adicionalmente, incluindo exportação de imagens do splash e dashboard. Relatórios de build e testes são fornecidos em `Documentation/Reports/`.

## Limites de validação

Executado em **Windows 11 Home x64**, build 26200. O alvo é Windows 10 **1809 ou posterior** x64, conforme o suporte do Qt 6.8; não foi executado numa máquina Windows 10 nesta sessão. O binário de desenvolvimento não está assinado digitalmente. Não há validação de rede, autenticação, atualizações ou jogo, porque esses componentes não existem na v0.1.0.

Na revisão visual anterior foram observados o executável portátil e a maximização da janela. O utilizador interrompeu o controlo do computador com Esc; a revisão posterior foi validada através dos testes da própria aplicação e imagens exportadas, sem retomar esse controlo manual.

## Revisão da interface e README GitHub

O botão Link account foi removido. Os três controlos da janela utilizam ícones Lucide (minus, square e x), adaptados para QPainter com a mesma geometria e centrados por QIcon. Os SVGs originais e a licença upstream estão incluídos. A revisão do dashboard usa scroll em janelas pequenas para evitar sobreposição de cartões; existe uma asserção de layout nos testes.

O README principal foi preparado para GitHub com logo e capturas locais. As instruções detalhadas do launcher foram movidas para `Building.md`. Não foi criado um repositório remoto nem publicado conteúdo.

## Backend e autenticação

Implementado em C# / .NET 10 com PostgreSQL real, migrations, contas, sessões, rotação, expiração e revogação. O build final tem zero avisos e zero erros. Foram aprovados nove testes de integração, sem skips, incluindo reinício da API, concorrência e persistência. O modo Production está bloqueado até às próximas etapas de segurança. Ver `Backend.md` e os relatórios de backend em `Reports/`.

## v0.1.1 — ligação do launcher à API

O indicador Offline fixo foi substituído por verificações reais de `/health/ready`. O launcher apresenta Checking API, API online ou API unavailable e repete a verificação a cada dez segundos. Settings inclui registo, login, perfil, renovação e logout reais. Os tokens permanecem em memória; os campos de password são limpos após as operações.

`SixMMasterClientTests` foi executado com uma API real sobre a base PostgreSQL de testes isolada: API indisponível, rejeição de HTTP remoto inseguro, registo pelos widgets, credenciais erradas, login, perfil, renovação, logout e indicador online. Resultado Qt: quatro resultados aprovados incluindo init/cleanup, sem falhas ou skips. A suite da API mantém nove testes aprovados. A fundação do launcher e o arranque continuam aprovados em CTest.

## Política de colaboração e identidade

A distribuição atual usa SixM Community Source License 1.0. Permite colaboração e alterações, exigindo preservar a identidade e os créditos SixM e identificar forks não oficiais. É uma licença personalizada de código disponível, não MIT. As permissões concedidas a cópias MIT anteriores não são retiradas retroativamente. Os termos de terceiros permanecem intactos. Não houve publicação remota destas alterações.
