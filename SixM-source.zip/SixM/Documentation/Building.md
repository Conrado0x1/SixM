# SixM — Launcher v0.1.1

A new era of multiplayer.

Launcher desktop em C++20 / Qt 6 Widgets. A v0.1.1 acrescenta ligação HTTP à API local, estado de disponibilidade real e registo/login/gestão de sessão em Settings. Mantém ecrã de arranque, navegação, configuração local e dashboard. Os servidores são demonstrações; não existe integração com GTA VI ou updater.

O design segue a última referência fornecida: fundo escuro, navegação horizontal, Browse Servers, Favorites/History, servidor em destaque e coluna de novidades locais. Mantém a identidade SixM em azul, o logo e o banner fornecidos. A navegação superior substitui a sidebar da primeira proposta visual.

O ecrã inicial apresenta três tarefas locais reais: carregar recursos, ler configurações e preparar a janela. Não simula downloads, verificações criptográficas nem atualizações remotas.

## Executar

Abrir `SixM.exe` na pasta portátil fornecida, mantendo as DLLs e a pasta `platforms` junto do executável. Alvo: Windows 10 1809 ou posterior, x64. O executável desta versão de desenvolvimento não está assinado digitalmente.

## Dependências para compilar

- Visual Studio 2022, workload **Desktop development with C++**, MSVC v143 x64 e Windows SDK.
- Qt **6.8.3**, kit **MSVC 2022 64-bit**, módulos qtbase e qttools, bibliotecas partilhadas.
- CMake 3.24 ou posterior; os presets usam CMake 3.25 ou posterior.
- Git para controlo de versões.

Qt Creator não é necessário. Pode abrir esta pasta no Visual Studio como projeto CMake. O kit Qt é uma combinação das bibliotecas Qt x64 e do compilador MSVC x64; não é necessário instalar um IDE adicional.

Instalação alternativa do Qt a partir dos arquivos oficiais com aqtinstall:

```powershell
py -m venv .tooling
.\.tooling\Scripts\python.exe -m pip install aqtinstall cmake
.\.tooling\Scripts\python.exe -m aqt install-qt windows desktop 6.8.3 win64_msvc2022_64 --outputdir C:\Qt --archives qtbase qttools
```

Na Developer PowerShell do VS 2022, com CMake no PATH:

```powershell
$env:SIXM_QT_ROOT = 'C:\Qt\6.8.3\msvc2022_64'
$env:PATH = "$env:SIXM_QT_ROOT\bin;$env:PATH"
cmake --preset windows-msvc2022
cmake --build --preset release
ctest --preset release
cmake --install build --config Release --prefix dist
& "$env:SIXM_QT_ROOT\bin\windeployqt.exe" --release --no-translations --no-opengl-sw --no-compiler-runtime dist\SixM.exe
```

Para distribuição noutras máquinas, fornecer o instalador oficial Microsoft Visual C++ Redistributable x64 ou os ficheiros runtime redistribuíveis autorizados. O pacote entregue contém o runtime app-local.

## Organização

- `Launcher/`: UI, recursos, configurações e entrada Windows.
- `Tests/`: testes Qt Test, sem aceder à configuração real do utilizador.
- `Documentation/`: arquitetura, ambiente, validação e roadmap.
- `Core/`, `Client/`, `Server/`, `Networking/`, `SDK/`, `Master/`, `Database/`: reservados para versões futuras; sem implementações fictícias.

O diretório é guardado via QSettings em `%APPDATA%\SixM\Launcher.ini`. O launcher apenas verifica se a pasta existe; não identifica executáveis do jogo. Não faz pedidos de rede nem recolhe credenciais. A interface inicial é inglesa, acompanhando as referências; seleção de idiomas fica para versão posterior.

## Recompilar nesta máquina

Foi preparada uma toolchain local em `../../work/msvc`, Qt em `../../work/Qt` e CMake em `../../work/tooling`. Nesta pasta pode executar `./Build-Local.ps1`; o script aceita outros caminhos como parâmetros. Estas dependências de desenvolvimento não estão incluídas no ZIP do código. Noutra máquina, instalar os requisitos acima e usar os presets.

O build prepara automaticamente as DLLs e os plugins Qt junto dos executáveis. O runtime MSVC tem de estar instalado ou ser fornecido app-local. O pacote portátil entregue já o inclui.

## Verificação do arranque

`SixM.exe --startup-check` percorre o arranque completo e termina com código 0 após abrir a janela. Para guardar imagens durante esse teste, definir `SIXM_STARTUP_CAPTURE` com uma pasta de destino. Sem essa opção de teste, o launcher permanece aberto normalmente. Ver `Documentation/Validation.md` para resultados e limitações.

## Referências técnicas

- [Qt 6.8 / Windows e compiladores suportados](https://doc.qt.io/qt-6.8/windows.html)
- [Deployment Windows com windeployqt](https://doc.qt.io/qt-6.8/windows-deployment.html)
- [aqtinstall](https://github.com/miurahr/aqtinstall)

Ver `THIRD_PARTY_NOTICES.md` antes de redistribuir. O logo e a arte panorâmica foram fornecidos pelo utilizador; a autorização de redistribuição pública deve ser confirmada pelo titular do projeto. Os recursos originais estão embebidos no executável; a imagem panorâmica foi apenas reencodificada para PNG porque o ficheiro fornecido continha WebP apesar da extensão PNG.
