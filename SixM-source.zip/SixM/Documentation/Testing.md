# Test the launcher and API together — v0.1.1

1. Keep SixM Master running locally at `http://127.0.0.1:5080`, with PostgreSQL available. Its console should say that the application has started.
2. Close the old launcher and open **SixM.exe from the v0.1.1 folder**. The older v0.1.0 executable does not contain the API connection.
3. The top status should change from **Checking API…** to **API online**. This means the account service and database are reachable; it does not mean multiplayer is available.
4. Open **Settings → Create account**. Enter a display name, email and a password of 12–128 characters, including uppercase, lowercase, a number and a symbol.
5. After account creation, use **Sign in**. The panel should show the profile returned by the API. Password fields clear when the request completes.
6. Click **Renew session**. A success message confirms that the API rotated the session tokens.
7. Click **Sign out**. The form should return, and the API should confirm server-side revocation.
8. Stop the API. Within about fifteen seconds, the launcher should show **API unavailable**. Restart the API and wait for the next check, or click **Check API connection** in Settings.

Credentials and tokens are not written to launcher settings. After closing the launcher, sign in again. Email verification and account recovery are not implemented yet.

Server cards remain clearly labeled demonstrations. Browse Servers and Connect cannot enter a game or a real multiplayer server in this version.

The automated integration runner uses a separate PostgreSQL test database. It verifies the API security flows and can run the Qt account forms against that API, including invalid credentials, successful sign-in, renewal, sign-out, and actual availability display.
