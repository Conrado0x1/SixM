param([string]$Dotnet, [switch]$UseWorkspaceConfiguration, [switch]$Migrate)
$ErrorActionPreference='Stop'
if (!$Dotnet) {
    $localSdk=Join-Path $PSScriptRoot '..\..\..\work\dotnet\dotnet.exe'
    $Dotnet=if (Test-Path -LiteralPath $localSdk) {(Resolve-Path -LiteralPath $localSdk).Path} else {'dotnet'}
}
if ($UseWorkspaceConfiguration) {
    $privatePath=Join-Path $PSScriptRoot '..\..\..\work\backend-private.json'
    if (!(Test-Path -LiteralPath $privatePath)) {throw 'Workspace configuration is unavailable. Supply ConnectionStrings__SixM privately.'}
    $config=Get-Content -LiteralPath $privatePath -Raw | ConvertFrom-Json
    $env:ConnectionStrings__SixM=$config.development
}
if (!$env:ConnectionStrings__SixM) {throw 'Supply ConnectionStrings__SixM privately or use -UseWorkspaceConfiguration on the prepared development machine.'}
if (!$env:ASPNETCORE_ENVIRONMENT) {$env:ASPNETCORE_ENVIRONMENT='Development'}
$runArgs=@('run','--project',(Join-Path $PSScriptRoot 'SixM.Master'),'-c','Release')
if ($Migrate) {$runArgs+=@('--','--migrate')}
& $Dotnet @runArgs
if ($LASTEXITCODE -ne 0) {throw 'SixM Master exited with an error.'}
