# SixM Master — authentication foundation

C# / ASP.NET Core 10 + PostgreSQL. Independente do launcher e do jogo. Esta etapa implementa contas locais, sessões opacas revogáveis, renovação de tokens e acesso protegido. Não é um fornecedor OAuth/OIDC nem fornece SSO.

## Configurar

Instalar .NET SDK 10 e PostgreSQL 18 (ou executar PostgreSQL com Docker). Criar uma base dedicada e um utilizador com permissões apenas nessa base. Não utilizar o superuser para a aplicação.

Na pasta `Master/`:

```powershell
$env:ASPNETCORE_ENVIRONMENT = 'Development'
# Definir ConnectionStrings__SixM com credenciais privadas.
# Local: Host=127.0.0.1;Port=5432;Database=sixm;Username=sixm_app;Password=...
# Remoto: usar TLS com SSL Mode=VerifyFull e uma CA confiável.
dotnet restore SixM.Master --locked-mode
dotnet run --project SixM.Master -- --migrate
dotnet run --project SixM.Master
```

O comando de migração aplica as migrations versionadas; o servidor não altera automaticamente o schema no arranque normal. Não há passwords, tokens ou connection strings reais no repositório. O serviço local usa `127.0.0.1:5080`. Variáveis do ambiente substituem appsettings; não incluir segredos nos argumentos da linha de comandos.

## API

| Método | Endpoint | Comportamento |
| --- | --- | --- |
| GET | `/health/live` | Processo disponível |
| GET | `/health/ready` | Conexão PostgreSQL disponível |
| POST | `/v1/auth/register` | `{ "email", "password", "displayName" }` |
| POST | `/v1/auth/login` | `{ "email", "password" }` → access token + refresh token |
| POST | `/v1/auth/refresh` | `{ "refreshToken" }` → par novo, invalida o anterior |
| GET | `/v1/me` | Perfil da sessão autenticada |
| POST | `/v1/auth/logout` | Revoga a sessão atual |
| POST | `/v1/auth/logout-all` | Revoga todas as sessões do utilizador |

Usar `Content-Type: application/json` e `Authorization: Bearer <accessToken>` nos endpoints protegidos. Não são utilizados cookies. Tokens são opacos, não JWT. Access tokens expiram em 15 minutos; a sessão tem duração absoluta máxima de 7 dias. O logout e a renovação invalidam os tokens anteriores na base de dados. Tokens devem ficar em memória ou num cofre do sistema operativo no futuro cliente; nunca em logs ou QSettings.

## Segurança desta etapa

- Passwords processadas pelo ASP.NET Core Identity (PBKDF2; 210 000 iterações configuradas), nunca guardadas em texto simples.
- Passwords de 12–128 caracteres com maiúscula, minúscula, número e símbolo.
- Tokens aleatórios de 256 bits; apenas SHA-256 dos tokens é persistido.
- Lockout após 5 tentativas falhadas por conta; limite de 30 pedidos de autenticação por minuto por IP.
- Rotação com controlo de concorrência: dois refresh simultâneos não podem consumir o mesmo token com sucesso.
- EF Core parametriza as consultas; JSON e tamanho do pedido são validados.
- Sem CORS permissivo, sem confiança automática em X-Forwarded-For, sem logs de credenciais.
- HTTP permitido apenas de loopback; acesso remoto requer HTTPS.

## Limites

O serviço está limitado ao ambiente Development. Confirmação de email, recuperação de password, MFA, gestão administrativa, observabilidade operacional e configuração de produção serão etapas posteriores. Os emails das contas locais ainda não são verificados. A partir do launcher v0.1.1, registo, login, perfil, renovação e logout podem ser testados em Settings. O botão Link account no topo continua removido conforme pedido.

## Testes

`Tests/RunMasterIntegration.py` compila e inicia uma API de testes, aplica migrations e executa `MasterAuthIntegration.py` contra PostgreSQL real. Usa apenas a biblioteca padrão Python. Executar apenas numa base de testes dedicada chamada `sixm_auth_tests`. Ver `Documentation/Backend.md` e o relatório de validação para o resultado desta sessão.
