using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SixM.Master.Data;

namespace SixM.Master.Auth;

public sealed record RegisterRequest(string? Email, string? Password, string? DisplayName);
public sealed record LoginRequest(string? Email, string? Password);
public sealed record RefreshRequest(string? RefreshToken);
public sealed record TokenResponse(string TokenType, string AccessToken, int ExpiresIn, string RefreshToken);

public sealed class LoginTimingMitigator(IPasswordHasher<SixMUser> hasher)
{
    private readonly SixMUser dummy = new();
    private readonly string hash = hasher.HashPassword(new SixMUser(), TokenCodec.Create());
    public void Check(string password) => hasher.VerifyHashedPassword(dummy, hash, password);
}

public static class AuthEndpoints
{
    private static readonly TimeSpan AccessLifetime = TimeSpan.FromMinutes(15);
    private static readonly TimeSpan SessionLifetime = TimeSpan.FromDays(7);

    public static void MapSixMAuth(this WebApplication app)
    {
        var routes = app.MapGroup("/v1/auth").RequireRateLimiting("auth");
        routes.MapPost("/register", Register);
        routes.MapPost("/login", Login);
        routes.MapPost("/refresh", Refresh);
        routes.MapPost("/logout", Logout).RequireAuthorization();
        routes.MapPost("/logout-all", LogoutAll).RequireAuthorization();
        app.MapGet("/v1/me", Me).RequireAuthorization();
    }

    private static bool ValidCredentials(string? email, string? password) =>
        email is { Length: > 0 and <= 254 } && new EmailAddressAttribute().IsValid(email)
        && password is { Length: >= 12 and <= 128 };

    private static async Task<IResult> Register(RegisterRequest input, UserManager<SixMUser> users)
    {
        if (!ValidCredentials(input.Email, input.Password) || string.IsNullOrWhiteSpace(input.DisplayName)
            || input.DisplayName.Trim().Length > 32 || input.DisplayName.Any(char.IsControl))
            return Results.BadRequest(new { error = "invalid_registration", passwordPolicy = "12–128 characters; uppercase, lowercase, number and symbol required." });
        var user = new SixMUser { Id = Guid.NewGuid(), UserName = input.Email!.Trim(), Email = input.Email.Trim(), DisplayName = input.DisplayName.Trim() };
        var result = await users.CreateAsync(user, input.Password!);
        if (!result.Succeeded)
            return Results.BadRequest(new { error = "registration_rejected" });
        return Results.Created("/v1/me", new { user.Id, user.DisplayName, user.EmailConfirmed });
    }

    private static async Task<IResult> Login(LoginRequest input, UserManager<SixMUser> users,
        SignInManager<SixMUser> signIn, AuthDbContext database, TimeProvider clock,
        LoginTimingMitigator timing, ILoggerFactory logger, CancellationToken cancellation)
    {
        if (!ValidCredentials(input.Email, input.Password)) return Results.Unauthorized();
        var user = await users.FindByEmailAsync(input.Email!.Trim());
        if (user is null) { timing.Check(input.Password!); return Results.Unauthorized(); }
        var result = await signIn.CheckPasswordSignInAsync(user, input.Password!, lockoutOnFailure: true);
        if (!result.Succeeded)
        {
            logger.CreateLogger("Security").LogWarning("Login rejected. LockedOut={LockedOut}", result.IsLockedOut);
            return Results.Unauthorized();
        }
        var now = clock.GetUtcNow();
        await database.Sessions.Where(s => s.UserId == user.Id && s.ExpiresAt <= now).ExecuteDeleteAsync(cancellation);
        var session = new AuthSession { Id = Guid.NewGuid(), UserId = user.Id, AccessHash = "", RefreshHash = "", CreatedAt = now, ExpiresAt = now + SessionLifetime };
        var tokens = Rotate(session, now);
        database.Sessions.Add(session); await database.SaveChangesAsync(cancellation);
        logger.CreateLogger("Security").LogInformation("Session created for user {UserId}.", user.Id);
        return Results.Ok(tokens);
    }

    private static TokenResponse Rotate(AuthSession session, DateTimeOffset now)
    {
        var access = TokenCodec.Create(); var refresh = TokenCodec.Create();
        session.AccessHash = TokenCodec.Hash(access)!; session.RefreshHash = TokenCodec.Hash(refresh)!;
        session.AccessExpiresAt = session.ExpiresAt < now + AccessLifetime ? session.ExpiresAt : now + AccessLifetime;
        session.Version++;
        return new TokenResponse("Bearer", access, (int)(session.AccessExpiresAt - now).TotalSeconds, refresh);
    }

    private static async Task<IResult> Refresh(RefreshRequest input, AuthDbContext database, TimeProvider clock, CancellationToken cancellation)
    {
        var hash = TokenCodec.Hash(input.RefreshToken);
        if (hash is null) return Results.Unauthorized();
        var now = clock.GetUtcNow();
        var session = await database.Sessions.SingleOrDefaultAsync(s => s.RefreshHash == hash && s.ExpiresAt > now, cancellation);
        if (session is null) return Results.Unauthorized();
        var tokens = Rotate(session, now);
        try { await database.SaveChangesAsync(cancellation); }
        catch (DbUpdateConcurrencyException) { return Results.Unauthorized(); }
        return Results.Ok(tokens);
    }

    private static async Task<IResult> Logout(ClaimsPrincipal principal, AuthDbContext database, CancellationToken cancellation)
    {
        var sessionId = Guid.Parse(principal.FindFirstValue("sid")!);
        await database.Sessions.Where(s => s.Id == sessionId).ExecuteDeleteAsync(cancellation);
        return Results.NoContent();
    }

    private static async Task<IResult> LogoutAll(ClaimsPrincipal principal, AuthDbContext database, CancellationToken cancellation)
    {
        var userId = Guid.Parse(principal.FindFirstValue(ClaimTypes.NameIdentifier)!);
        await database.Sessions.Where(s => s.UserId == userId).ExecuteDeleteAsync(cancellation);
        return Results.NoContent();
    }

    private static async Task<IResult> Me(ClaimsPrincipal principal, AuthDbContext database, CancellationToken cancellation)
    {
        var userId = Guid.Parse(principal.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var user = await database.Users.AsNoTracking().Where(u => u.Id == userId)
            .Select(u => new { u.Id, u.DisplayName, u.Email, u.EmailConfirmed }).SingleOrDefaultAsync(cancellation);
        return user is null ? Results.Unauthorized() : Results.Ok(user);
    }
}
