using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SixM.Master.Data;

namespace SixM.Master.Auth;

public sealed class SessionAuthenticationHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder,
    AuthDbContext database,
    TimeProvider clock) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "SixMSession";

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var authorization = Request.Headers.Authorization.ToString();
        if (authorization.Length == 0) return AuthenticateResult.NoResult();
        if (!authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            return AuthenticateResult.Fail("Invalid authentication scheme.");
        var hash = TokenCodec.Hash(authorization[7..]);
        if (hash is null) return AuthenticateResult.Fail("Invalid session.");
        var now = clock.GetUtcNow();
        var session = await database.Sessions.AsNoTracking().SingleOrDefaultAsync(
            s => s.AccessHash == hash && s.AccessExpiresAt > now && s.ExpiresAt > now,
            Context.RequestAborted);
        if (session is null) return AuthenticateResult.Fail("Invalid session.");
        var identity = new ClaimsIdentity([
            new Claim(ClaimTypes.NameIdentifier, session.UserId.ToString()),
            new Claim("sid", session.Id.ToString())
        ], SchemeName);
        return AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(identity), SchemeName));
    }
}
