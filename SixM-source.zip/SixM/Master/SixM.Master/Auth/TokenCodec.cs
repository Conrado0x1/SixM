using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.WebUtilities;

namespace SixM.Master.Auth;

public static class TokenCodec
{
    public static string Create() => WebEncoders.Base64UrlEncode(RandomNumberGenerator.GetBytes(32));

    public static string? Hash(string? token)
    {
        if (token is not { Length: 43 } || token.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '-' && c != '_'))
            return null;
        return Convert.ToHexString(SHA256.HashData(Encoding.ASCII.GetBytes(token)));
    }
}
