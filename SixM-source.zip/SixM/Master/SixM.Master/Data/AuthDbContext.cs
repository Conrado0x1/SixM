using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace SixM.Master.Data;

public sealed class SixMUser : IdentityUser<Guid>
{
    public string DisplayName { get; set; } = "";
}

public sealed class AuthSession
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public required string AccessHash { get; set; }
    public required string RefreshHash { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset AccessExpiresAt { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public long Version { get; set; }
}

public sealed class AuthDbContext(DbContextOptions<AuthDbContext> options)
    : IdentityDbContext<SixMUser, IdentityRole<Guid>, Guid>(options)
{
    public DbSet<AuthSession> Sessions => Set<AuthSession>();

    protected override void OnModelCreating(ModelBuilder model)
    {
        base.OnModelCreating(model);
        model.Entity<SixMUser>().Property(u => u.DisplayName).HasMaxLength(32);
        model.Entity<AuthSession>(session =>
        {
            session.ToTable("auth_sessions");
            session.HasKey(s => s.Id);
            session.Property(s => s.AccessHash).HasMaxLength(64);
            session.Property(s => s.RefreshHash).HasMaxLength(64);
            session.HasIndex(s => s.AccessHash).IsUnique();
            session.HasIndex(s => s.RefreshHash).IsUnique();
            session.HasIndex(s => s.ExpiresAt);
            session.HasIndex(s => s.UserId);
            session.Property(s => s.Version).IsConcurrencyToken();
            session.HasOne<SixMUser>().WithMany().HasForeignKey(s => s.UserId).OnDelete(DeleteBehavior.Cascade);
        });
    }
}
