param(
    [string]$ToolchainRoot = (Join-Path $PSScriptRoot '..\..\work\msvc'),
    [string]$QtRoot = (Join-Path $PSScriptRoot '..\..\work\Qt\6.8.3\msvc2022_64'),
    [string]$CMake = (Join-Path $PSScriptRoot '..\..\work\tooling\Scripts\cmake.exe'),
    [string]$BuildRoot = (Join-Path $PSScriptRoot '..\..\work\build-msvc')
)
$ErrorActionPreference = 'Stop'
$ToolchainRoot = (Resolve-Path -LiteralPath $ToolchainRoot).Path
$QtRoot = (Resolve-Path -LiteralPath $QtRoot).Path
$CMake = (Resolve-Path -LiteralPath $CMake).Path
$vc = Get-ChildItem -LiteralPath "$ToolchainRoot\VC\Tools\MSVC" -Directory | Sort-Object Name -Descending | Select-Object -First 1
$sdk = Get-ChildItem -LiteralPath "$ToolchainRoot\Windows Kits\10\Include" -Directory | Sort-Object Name -Descending | Select-Object -First 1
if (!$vc -or !$sdk) { throw 'MSVC headers and Windows SDK are required.' }
$kits = "$ToolchainRoot\Windows Kits\10"
$env:PATH = "$($vc.FullName)\bin\Hostx64\x64;$kits\bin\$($sdk.Name)\x64;$QtRoot\bin;$env:PATH"
$env:INCLUDE = "$($vc.FullName)\include;$kits\Include\$($sdk.Name)\ucrt;$kits\Include\$($sdk.Name)\shared;$kits\Include\$($sdk.Name)\um;$kits\Include\$($sdk.Name)\winrt"
$env:LIB = "$($vc.FullName)\lib\x64;$kits\Lib\$($sdk.Name)\ucrt\x64;$kits\Lib\$($sdk.Name)\um\x64"
& $CMake -S $PSScriptRoot -B $BuildRoot -G 'NMake Makefiles' -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$QtRoot" -DBUILD_TESTING=ON
if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed.' }
& $CMake --build $BuildRoot
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
& (Join-Path (Split-Path $CMake) 'ctest.exe') --test-dir $BuildRoot -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw 'Tests failed.' }
