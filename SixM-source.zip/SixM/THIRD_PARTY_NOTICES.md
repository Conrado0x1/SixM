# Third-party notices — SixM v0.1.0

The minimize, maximize and close icons use Lucide's minus, square and x geometry, adapted to QPainter. Original SVGs are in `Launcher/Assets/Lucide/`; the complete upstream license is in `Licenses/Lucide-LICENSE.txt`. https://lucide.dev .

Qt 6.8.3 Core, Gui, Widgets, Network and platform/image/style/TLS plugins are distributed as separate, dynamically linked libraries. Qt is copyright The Qt Company Ltd. and other contributors. Qt libraries used here are available under the GNU Lesser General Public License version 3, with applicable Qt exceptions and third-party notices. Qt Test is used only in the development test executable.

License texts are supplied in `Licenses/`. The corresponding unmodified Qt Base 6.8.3 source archive is supplied separately with this delivery. Official source: https://download.qt.io/archive/qt/6.8/6.8.3/submodules/qtbase-everywhere-src-6.8.3.tar.xz . Third-party licenses and copyright notices for bundled Qt dependencies are included in that source archive. Qt DLLs are replaceable in the portable package; no signature enforcement prevents replacement. The application source and build instructions are supplied to support rebuilding against a compatible Qt installation.

Microsoft Visual C++ runtime DLLs are Microsoft software, supplied app-local from the Microsoft compiler distribution. They are governed by Microsoft's applicable redistributable terms, not the Qt license. Official redistributable information: https://learn.microsoft.com/cpp/windows/latest-supported-vc-redist . Windows system libraries remain part of Windows.

The panoramic city artwork and the SixM logo were supplied by the project owner as design assets and are included in this private development delivery. Their provenance and permission for public distribution have not been established. The supplied logo is also used for the app icon. The launcher does not include game binaries, extracted game assets or Rockstar logos.

SixM is an independent project, not affiliated with Rockstar Games or Take-Two Interactive. Current distributions of SixM's original application code use the SixM Community Source License; see LICENSE. Earlier MIT grants remain applicable to copies supplied under MIT. The project license does not replace third-party licenses or claim ownership of third-party code, trademarks, or separately licensed artwork.
