"""End-to-end auth tests. Requires a real local API and a dedicated PostgreSQL test DB.

SIXM_TEST_API: loopback URL (default http://127.0.0.1:5089)
SIXM_TEST_PSQL: path to psql; PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD
RESTART_SERVER can be supplied by a local test harness to verify durable sessions.
Never run against a database containing real user accounts.
"""
import concurrent.futures
import json
import os
import secrets
import subprocess
import unittest
import urllib.error
import urllib.parse
import urllib.request
import uuid

BASE = os.environ.get('SIXM_TEST_API', 'http://127.0.0.1:5089')
if urllib.parse.urlparse(BASE).hostname not in ('127.0.0.1', 'localhost', '::1'):
    raise RuntimeError('Integration tests must target a loopback API.')
RESTART_SERVER = None


def request(method, path, body=None, access=None):
    headers = {'Content-Type': 'application/json'}
    if access:
        headers['Authorization'] = 'Bearer ' + access
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        response = urllib.request.urlopen(req, timeout=15)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        raw = response.read()
        return response.status, json.loads(raw) if raw else None


def sql(query):
    psql = os.environ.get('SIXM_TEST_PSQL')
    if not psql or os.environ.get('PGDATABASE') != 'sixm_auth_tests':
        raise RuntimeError('Database assertions require psql and PGDATABASE=sixm_auth_tests.')
    result = subprocess.run([psql, '-X', '-At', '-v', 'ON_ERROR_STOP=1'],
                            input=query.encode(), capture_output=True, check=True,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    return result.stdout.decode().strip()


class MasterAuthTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.email = 'sixm-test-' + uuid.uuid4().hex + '@example.invalid'
        cls.password = 'SixM!7' + secrets.token_urlsafe(24)
        code, user = request('POST', '/v1/auth/register', {
            'email': cls.email, 'password': cls.password, 'displayName': 'Integration Test'})
        if code != 201:
            raise RuntimeError('Test account registration failed, status=' + str(code))
        cls.user_id = user['id']

    def login(self):
        code, tokens = request('POST', '/v1/auth/login', {'email': self.email, 'password': self.password})
        self.assertEqual(code, 200)
        self.assertEqual(tokens['tokenType'], 'Bearer')
        self.assertEqual(tokens['expiresIn'], 900)
        self.assertEqual(len(tokens['accessToken']), 43)
        return tokens

    def test_00_sessions_survive_service_restart(self):
        if RESTART_SERVER is None:
            self.skipTest('Supply RESTART_SERVER from a process-owning test harness.')
        tokens = self.login()
        RESTART_SERVER()
        self.assertEqual(request('GET', '/v1/me', access=tokens['accessToken'])[0], 200)
        self.assertEqual(request('POST', '/v1/auth/logout', access=tokens['accessToken'])[0], 204)

    def test_01_registration_validation(self):
        for body in [
            {'email': 'not-an-email', 'password': self.password, 'displayName': 'Test'},
            {'email': self.email, 'password': 'short', 'displayName': 'Test'},
            {'email': self.email, 'password': self.password, 'displayName': '\n'},
            {'email': self.email, 'password': self.password, 'displayName': 'Duplicate'},
        ]:
            self.assertEqual(request('POST', '/v1/auth/register', body)[0], 400)

    def test_02_unauthorized_and_wrong_credentials(self):
        self.assertEqual(request('GET', '/v1/me')[0], 401)
        self.assertEqual(request('GET', '/v1/me', access='forged')[0], 401)
        for email, password in [('missing@example.invalid', self.password), (self.email, 'Incorrect!12345')]:
            self.assertEqual(request('POST', '/v1/auth/login', {'email': email, 'password': password})[0], 401)

    def test_03_refresh_rotation_and_logout(self):
        old = self.login()
        code, profile = request('GET', '/v1/me', access=old['accessToken'])
        self.assertEqual(code, 200)
        self.assertEqual(profile['email'], self.email)
        self.assertFalse(profile['emailConfirmed'])
        code, new = request('POST', '/v1/auth/refresh', {'refreshToken': old['refreshToken']})
        self.assertEqual(code, 200)
        self.assertTrue(old['accessToken'] != new['accessToken'])
        self.assertEqual(request('GET', '/v1/me', access=old['accessToken'])[0], 401)
        self.assertEqual(request('POST', '/v1/auth/refresh', {'refreshToken': old['refreshToken']})[0], 401)
        self.assertEqual(request('POST', '/v1/auth/logout', access=new['accessToken'])[0], 204)
        self.assertEqual(request('GET', '/v1/me', access=new['accessToken'])[0], 401)
        self.assertEqual(request('POST', '/v1/auth/refresh', {'refreshToken': new['refreshToken']})[0], 401)

    def test_04_concurrent_refresh_single_use(self):
        old = self.login()
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(lambda _: request('POST', '/v1/auth/refresh', {'refreshToken': old['refreshToken']}), range(2)))
        self.assertEqual(sorted(code for code, _ in outcomes), [200, 401])
        current = next(tokens for code, tokens in outcomes if code == 200)
        self.assertEqual(request('POST', '/v1/auth/logout', access=current['accessToken'])[0], 204)

    def test_05_lockout_persists_in_database(self):
        email = 'lockout-' + uuid.uuid4().hex + '@example.invalid'
        self.assertEqual(request('POST', '/v1/auth/register', {'email': email, 'password': self.password, 'displayName': 'Lockout test'})[0], 201)
        for _ in range(5):
            self.assertEqual(request('POST', '/v1/auth/login', {'email': email, 'password': 'Incorrect!12345'})[0], 401)
        self.assertEqual(request('POST', '/v1/auth/login', {'email': email, 'password': self.password})[0], 401)

    def test_06_logout_all_revokes_other_sessions(self):
        first, second = self.login(), self.login()
        self.assertEqual(request('POST', '/v1/auth/logout-all', access=first['accessToken'])[0], 204)
        for tokens in [first, second]:
            self.assertEqual(request('GET', '/v1/me', access=tokens['accessToken'])[0], 401)

    def test_07_expiry_and_secret_storage(self):
        tokens = self.login()
        hashes = sql(f'SELECT "AccessHash", "RefreshHash" FROM auth_sessions WHERE "UserId" = \'{self.user_id}\';')
        self.assertTrue(tokens['accessToken'] not in hashes)
        self.assertTrue(tokens['refreshToken'] not in hashes)
        self.assertTrue(all(len(part) == 64 for row in hashes.splitlines() for part in row.split('|')))
        password_hash = sql(f'SELECT "PasswordHash" FROM "AspNetUsers" WHERE "Id" = \'{self.user_id}\';')
        self.assertTrue(self.password not in password_hash)
        self.assertGreater(len(password_hash), 60)
        self.assertEqual(sql("SELECT rolsuper FROM pg_roles WHERE rolname = current_user;"), 'f')
        sql(f'UPDATE auth_sessions SET "AccessExpiresAt" = now() - interval \'1 minute\' WHERE "UserId" = \'{self.user_id}\';')
        self.assertEqual(request('GET', '/v1/me', access=tokens['accessToken'])[0], 401)
        code, fresh = request('POST', '/v1/auth/refresh', {'refreshToken': tokens['refreshToken']})
        self.assertEqual(code, 200)
        sql(f'UPDATE auth_sessions SET "ExpiresAt" = now() - interval \'1 minute\' WHERE "UserId" = \'{self.user_id}\';')
        self.assertEqual(request('GET', '/v1/me', access=fresh['accessToken'])[0], 401)
        self.assertEqual(request('POST', '/v1/auth/refresh', {'refreshToken': fresh['refreshToken']})[0], 401)

    def test_09_rate_limit(self):
        statuses = [request('POST', '/v1/auth/refresh', {'refreshToken': 'invalid'})[0] for _ in range(35)]
        self.assertIn(429, statuses)
        self.assertTrue(all(code in (401, 429) for code in statuses))


if __name__ == '__main__':
    unittest.main(verbosity=2)
