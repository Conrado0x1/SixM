"""Build and test SixM Master against a dedicated PostgreSQL database.

Required: ConnectionStrings__SixM targeting sixm_auth_tests; SIXM_TEST_PSQL;
PGHOST, PGPORT, PGDATABASE=sixm_auth_tests, PGUSER, PGPASSWORD.
All credentials are read from the environment and are never printed.
"""
from pathlib import Path
import argparse
import importlib.util
import os
import re
import shutil
import subprocess
import sys
import time
import unittest
import urllib.request

parser=argparse.ArgumentParser()
parser.add_argument('--dotnet',default=shutil.which('dotnet'))
parser.add_argument('--report-dir',type=Path,default=Path.cwd()/'work/master-tests')
parser.add_argument('--launcher-tests',type=Path,help='Optional Qt launcher/API integration test executable.')
arguments=parser.parse_args()
if not arguments.dotnet:
    parser.error('.NET SDK 10 is required; supply --dotnet.')
connection=os.environ.get('ConnectionStrings__SixM','')
if os.environ.get('PGDATABASE')!='sixm_auth_tests' or not re.search(r'(?:^|;)\s*Database\s*=\s*sixm_auth_tests\s*(?:;|$)',connection,re.I):
    parser.error('ConnectionStrings__SixM and PGDATABASE must both target sixm_auth_tests.')
if not os.environ.get('SIXM_TEST_PSQL') or not os.environ.get('PGPASSWORD'):
    parser.error('Configure psql and the test database credentials in the environment.')
root=Path(__file__).resolve().parents[1]
project=root/'Master/SixM.Master'
reports=arguments.report_dir.resolve(); reports.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
env.update(ASPNETCORE_ENVIRONMENT='Development',ASPNETCORE_URLS='http://127.0.0.1:5089',DOTNET_CLI_TELEMETRY_OPTOUT='1')
os.environ['SIXM_TEST_API']='http://127.0.0.1:5089'
flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
with (reports/'Build.txt').open('wb') as build:
    for command in [
        ['restore',str(project),'--locked-mode'],
        ['build',str(project),'-c','Release','--no-restore'],
        ['run','--project',str(project),'-c','Release','--no-build','--','--migrate'],
    ]:
        subprocess.run([arguments.dotnet]+command,env=env,stdout=build,stderr=subprocess.STDOUT,check=True,creationflags=flags)
service_log=(reports/'Service.txt').open('wb')
process=None
production=env.copy(); production['ASPNETCORE_ENVIRONMENT']='Production'; production['DOTNET_ENVIRONMENT']='Production'
with (reports/'ProductionGuard.txt').open('wb') as guard:
    denied=subprocess.run([arguments.dotnet,str(project/'bin/Release/net10.0/SixM.Master.dll')],cwd=project,
                          env=production,stdout=guard,stderr=subprocess.STDOUT,creationflags=flags,timeout=15)
if denied.returncode==0:
    raise RuntimeError('Production guard did not reject startup.')

def start():
    global process
    process=subprocess.Popen([arguments.dotnet,str(project/'bin/Release/net10.0/SixM.Master.dll')],
                             cwd=project,env=env,stdout=service_log,stderr=subprocess.STDOUT,creationflags=flags)
    deadline=time.monotonic()+15
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    while time.monotonic()<deadline:
        if process.poll() is not None:
            raise RuntimeError('Test API exited. Inspect Service.txt.')
        try:
            with opener.open('http://127.0.0.1:5089/health/ready',timeout=.4) as response:
                if response.status==200: return
        except (OSError,urllib.error.URLError):
            time.sleep(.1)
    raise RuntimeError('Test API readiness timed out.')

def stop():
    if process and process.poll() is None:
        process.terminate(); process.wait(timeout=10)

def restart():
    stop(); start()

try:
    start()
    specification=importlib.util.spec_from_file_location('master_tests',Path(__file__).with_name('MasterAuthIntegration.py'))
    module=importlib.util.module_from_spec(specification); specification.loader.exec_module(module)
    module.RESTART_SERVER=restart
    with (reports/'Integration.txt').open('w',encoding='utf-8') as report:
        result=unittest.TextTestRunner(stream=report,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
    print(f'{result.testsRun} integration tests; {len(result.failures)} failures; {len(result.errors)} errors; {len(result.skipped)} skipped.')
    if not result.wasSuccessful(): sys.exit(1)
    if arguments.launcher_tests:
        restart()
        launcher_env=env.copy()
        launcher_env['SIXM_TEST_MASTER_URL']='http://127.0.0.1:5089'
        launcher_env['SIXM_SCREENSHOT_DIR']=str(reports)
        subprocess.run([str(arguments.launcher_tests.resolve()),'-platform','windows','-o',str(reports/'LauncherMaster.txt')+',txt'],
                       env=launcher_env,check=True,creationflags=flags)
        print('Launcher/API integration passed against the isolated PostgreSQL test database.')
finally:
    stop(); service_log.close()
