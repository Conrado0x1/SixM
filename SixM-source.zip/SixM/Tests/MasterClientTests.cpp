#include "MasterClient.h"
#include "AccountWidget.h"
#include "MainWindow.h"
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTabWidget>
#include <QUuid>
#include <QtTest>

class MasterClientTests final:public QObject {
    Q_OBJECT
private slots:
    void unavailableAndUnsafeEndpoints() {
        sixm::MasterClient unavailable(QUrl("http://127.0.0.1:1"));
        QTRY_COMPARE_WITH_TIMEOUT(unavailable.status(),sixm::MasterClient::Status::Unavailable,7000);
        sixm::MasterClient unsafe(QUrl("http://example.com"));
        QVERIFY(unsafe.endpoint().isEmpty());
        unsafe.checkHealth();
        QCOMPARE(unsafe.status(),sixm::MasterClient::Status::Unavailable);
    }
    void realAccountFlowThroughWidgets() {
        const QUrl url(qEnvironmentVariable("SIXM_TEST_MASTER_URL"));
        QVERIFY2(!url.isEmpty(),"Set SIXM_TEST_MASTER_URL to a running test API.");
        sixm::MasterClient client(url);
        sixm::AccountWidget widget(&client);
        widget.resize(850,550);widget.show();
        QVERIFY(QTest::qWaitForWindowExposed(&widget));
        QTRY_COMPARE_WITH_TIMEOUT(client.status(),sixm::MasterClient::Status::Online,7000);
        const QString email="qt-"+QUuid::createUuid().toString(QUuid::Id128)+"@example.invalid";
        const QString password="SixM!7"+QUuid::createUuid().toString(QUuid::Id128);
        auto* tabs=widget.findChild<QTabWidget*>();
        auto* message=widget.findChild<QLabel*>("accountMessage");
        QVERIFY(tabs && message);
        tabs->setCurrentIndex(1);
        widget.findChild<QLineEdit*>("registerName")->setText("Launcher Integration Test");
        widget.findChild<QLineEdit*>("registerEmail")->setText(email);
        widget.findChild<QLineEdit*>("registerPassword")->setText(password);
        QTest::mouseClick(widget.findChild<QPushButton*>("registerButton"),Qt::LeftButton);
        QTRY_VERIFY_WITH_TIMEOUT(message->text().contains("Account created"),10000);
        QCOMPARE(tabs->currentIndex(),0);
        auto* input=widget.findChild<QLineEdit*>("loginPassword");
        QCOMPARE(input->echoMode(),QLineEdit::Password);
        input->setText("Incorrect!12345");
        QTest::mouseClick(widget.findChild<QPushButton*>("signInButton"),Qt::LeftButton);
        QTRY_VERIFY_WITH_TIMEOUT(message->text().contains("Sign-in failed"),10000);
        QVERIFY(!client.signedIn());
        input->setText(password);
        QTest::mouseClick(widget.findChild<QPushButton*>("signInButton"),Qt::LeftButton);
        QTRY_VERIFY_WITH_TIMEOUT(message->text().contains("Signed in"),10000);
        QVERIFY(client.signedIn());
        QCOMPARE(client.profile().value("email").toString(),email);
        QVERIFY(input->text().isEmpty());
        QVERIFY(widget.findChild<QLabel*>("accountProfile")->text().contains("Launcher Integration Test"));
        QTest::mouseClick(widget.findChild<QPushButton*>("refreshSessionButton"),Qt::LeftButton);
        QTRY_VERIFY_WITH_TIMEOUT(message->text().contains("renewed successfully"),10000);
        QTest::mouseClick(widget.findChild<QPushButton*>("signOutButton"),Qt::LeftButton);
        QTRY_VERIFY_WITH_TIMEOUT(message->text().contains("server session was revoked"),10000);
        QVERIFY(!client.signedIn());
        QVERIFY(client.profile().isEmpty());
        sixm::MainWindow window(nullptr,url);
        window.show();
        QTRY_VERIFY_WITH_TIMEOUT(window.findChild<QLabel*>("apiStatus")->text().contains("online"),7000);
        const auto capture=qEnvironmentVariable("SIXM_SCREENSHOT_DIR");
        if(!capture.isEmpty()) {
            window.navigate(sixm::Page::Settings);QTest::qWait(100);
            QVERIFY(window.grab().save(capture+"/SixM-Account.png"));
            window.navigate(sixm::Page::Home);QTest::qWait(100);
            QVERIFY(window.grab().save(capture+"/SixM-Connected.png"));
        }
    }
};
QTEST_MAIN(MasterClientTests)
#include "MasterClientTests.moc"
