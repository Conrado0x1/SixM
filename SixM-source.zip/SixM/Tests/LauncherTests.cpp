#include "AppSettings.h"
#include "MainWindow.h"
#include "SplashScreen.h"
#include <QDir>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QProgressBar>
#include <QFrame>
#include <QTemporaryDir>
#include <QtTest>

class LauncherTests final : public QObject {
    Q_OBJECT
private slots:
    void initTestCase() {
        QVERIFY(config_.isValid());
        QSettings::setPath(QSettings::IniFormat, QSettings::UserScope, config_.path());
        QApplication::setStyle("Fusion");
    }
    void assetsEmbedded() {
        QVERIFY(!QPixmap(":/sixm/city.png").isNull());
        QVERIFY(!QPixmap(":/sixm/icon.png").isNull());
        QVERIFY(!QPixmap(":/sixm/logo.png").isNull());
    }
    void navigationAndHonestOfflineState() {
        sixm::MainWindow window(nullptr,QUrl("http://127.0.0.1:1"));
        window.show();
        QVERIFY(QTest::qWaitForWindowExposed(&window));
        QCOMPARE(window.currentPage(), sixm::Page::Home);
        QVERIFY(!window.findChild<QPushButton*>("accountButton"));
        for(auto* button:window.findChildren<QPushButton*>()) {
            if(button->property("chrome").toBool()) {
                QVERIFY(button->text().isEmpty());
                QVERIFY(!button->icon().isNull());
            }
        }
        for (const auto& name : {"Servers", "Favorites", "Settings", "About", "Home"}) {
            auto* button = window.findChild<QPushButton*>(QString("nav") + name);
            QVERIFY(button);
            QTest::mouseClick(button, Qt::LeftButton);
            QVERIFY(button->isChecked());
            QVERIFY(window.findChild<QLabel*>("apiStatus")->text().contains("API"));
        }
        QTest::mouseClick(window.findChild<QPushButton*>("exploreButton"), Qt::LeftButton);
        QCOMPARE(window.currentPage(), sixm::Page::Servers);
        auto* connect = window.findChild<QPushButton*>("connectUnavailable");
        QVERIFY(connect);
        QVERIFY(!connect->isEnabled());
        QTRY_VERIFY(window.findChild<QLabel*>("apiStatus")->text().contains("unavailable"));
        window.navigate(sixm::Page::Home);
        QTest::mouseClick(window.findChild<QPushButton*>("historyTile"),Qt::LeftButton);
        QCOMPARE(window.currentPage(),sixm::Page::History);
    }
    void settingsRejectInvalidAndPersistValidDirectory() {
        QTemporaryDir game;
        QVERIFY(game.isValid());
        sixm::MainWindow window;
        window.navigate(sixm::Page::Settings);
        auto* field = window.findChild<QLineEdit*>("gameDirectory");
        auto* save = window.findChild<QPushButton*>("saveDirectoryButton");
        QVERIFY(field && save);
        field->setText(game.path() + "/missing");
        save->click();
        QVERIFY(window.findChild<QLabel*>("settingsMessage")->text().contains("not found"));
        field->setText(game.path());
        save->click();
        sixm::AppSettings persisted;
        QCOMPARE(persisted.gameDirectory(), game.path());
        sixm::MainWindow reopened;
        QCOMPARE(reopened.findChild<QLineEdit*>("gameDirectory")->text(), game.path());
        QVERIFY(persisted.saveGameDirectory({}));
        QCOMPARE(persisted.gameDirectory(), QString{});
    }
    void startupProgressReflectsCompletedTasks() {
        sixm::SplashScreen splash;
        auto* progress=splash.findChild<QProgressBar*>("startupProgress");
        QVERIFY(progress);
        QCOMPARE(progress->value(),0);
        splash.setStage(2,"Local settings loaded.");
        QCOMPARE(progress->value(),2);
        QCOMPARE(splash.findChild<QLabel*>("startupMessage")->text(),QString("Local settings loaded."));
        splash.setStage(3,"SixM is ready.");
        QCOMPARE(progress->value(),progress->maximum());
    }
    void renderAtSupportedSizes() {
        sixm::MainWindow window;
        const QString capture = qEnvironmentVariable("SIXM_SCREENSHOT_DIR");
        for (const QSize size : {QSize(1440, 900), QSize(1200, 780)}) {
            window.resize(size);
            window.show();
            QTest::qWait(150);
            QCOMPARE(window.size(), size);
            auto* spotlight=window.findChild<QFrame*>("spotlight");
            auto* strip=window.findChild<QLabel*>("communityStrip");
            QVERIFY(spotlight && strip);
            QVERIFY(spotlight->geometry().bottom()<strip->geometry().top());
            if (!capture.isEmpty()) {
                QVERIFY(QDir().mkpath(capture));
                QVERIFY(window.grab().save(capture + QString("/SixM-%1x%2.png").arg(size.width()).arg(size.height())));
            }
        }
    }
private:
    QTemporaryDir config_;
};
QTEST_MAIN(LauncherTests)
#include "LauncherTests.moc"
