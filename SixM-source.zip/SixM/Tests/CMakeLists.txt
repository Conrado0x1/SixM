qt_add_executable(SixMLauncherTests LauncherTests.cpp ../Launcher/assets.qrc)
target_link_libraries(SixMLauncherTests PRIVATE SixMLauncher Qt6::Test)
target_compile_options(SixMLauncherTests PRIVATE /W4 /permissive- /utf-8)
get_target_property(_qmake Qt6::qmake IMPORTED_LOCATION)
get_filename_component(_qtTools "${_qmake}" DIRECTORY)
add_custom_command(TARGET SixMLauncherTests POST_BUILD
    COMMAND "${_qtTools}/windeployqt.exe" --release --no-translations --no-opengl-sw --no-compiler-runtime
        --no-system-d3d-compiler --no-system-dxc-compiler
        --skip-plugin-types generic,networkinformation "$<TARGET_FILE:SixMLauncherTests>"
    COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_qtTools}/../plugins/platforms/qoffscreen.dll" "$<TARGET_FILE_DIR:SixMLauncherTests>/platforms/"
    VERBATIM)
add_test(NAME launcher-foundation COMMAND SixMLauncherTests -platform offscreen)
get_target_property(_qtCore Qt6::Core IMPORTED_LOCATION_RELEASE)
get_filename_component(_qtBin "${_qtCore}" DIRECTORY)
get_filename_component(_qtPrefix "${_qtBin}" DIRECTORY)
set_tests_properties(launcher-foundation PROPERTIES
    TIMEOUT 60
    ENVIRONMENT "QT_PLUGIN_PATH=${_qtPrefix}/plugins"
    ENVIRONMENT_MODIFICATION "PATH=path_list_prepend:${_qtBin}")
add_test(NAME launcher-startup COMMAND SixM --startup-check -platform offscreen)
set_tests_properties(launcher-startup PROPERTIES TIMEOUT 30
    ENVIRONMENT "QT_PLUGIN_PATH=${_qtPrefix}/plugins")
qt_add_executable(SixMMasterClientTests MasterClientTests.cpp ../Launcher/assets.qrc)
target_link_libraries(SixMMasterClientTests PRIVATE SixMLauncher Qt6::Test)
target_compile_options(SixMMasterClientTests PRIVATE /W4 /permissive- /utf-8)
add_custom_command(TARGET SixMMasterClientTests POST_BUILD
    COMMAND "${_qtTools}/windeployqt.exe" --release --no-translations --no-opengl-sw --no-compiler-runtime
        --no-system-d3d-compiler --no-system-dxc-compiler --skip-plugin-types generic,networkinformation "$<TARGET_FILE:SixMMasterClientTests>"
    VERBATIM)
