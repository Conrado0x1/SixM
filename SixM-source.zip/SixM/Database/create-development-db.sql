-- Run with psql as a database administrator. No password is stored in this file.
CREATE ROLE sixm_app LOGIN;
\password sixm_app
CREATE DATABASE sixm OWNER sixm_app;
