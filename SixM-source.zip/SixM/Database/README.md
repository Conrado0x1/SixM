# Database

O schema de autenticação é versionado nas migrations EF Core de `Master/SixM.Master/Data/Migrations/`. As migrations são a fonte de verdade; não editar manualmente tabelas Identity.

`create-development-db.sql` cria um role sem privilégios de superuser e uma base dedicada. Executar com psql como administrador; o comando `\password` pede a password interativamente. A aplicação usa apenas esse role e a connection string é fornecida por variável do ambiente.
