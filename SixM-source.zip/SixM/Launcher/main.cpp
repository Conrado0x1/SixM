#include "MainWindow.h"
#include "SplashScreen.h"
#include <QApplication>
#include <QDir>
#include <QFile>
#include <QFont>
#include <QIcon>
#include <QMessageBox>
#include <QTimer>
#include <memory>
int main(int argc,char* argv[]) {
    QApplication app(argc,argv);
    QApplication::setOrganizationName("SixM"); QApplication::setApplicationName("SixM Launcher");
    QApplication::setApplicationVersion(SIXM_VERSION); QApplication::setStyle("Fusion");
    QApplication::setFont(QFont("Segoe UI",10)); QApplication::setWindowIcon(QIcon(":/sixm/icon.png"));
    QApplication::setQuitOnLastWindowClosed(false);
    const bool check=app.arguments().contains("--startup-check");
    sixm::SplashScreen splash; splash.show();
    std::unique_ptr<sixm::MainWindow> window;
    QTimer bootstrap; bootstrap.setInterval(170);
    int task=0;
    QObject::connect(&bootstrap,&QTimer::timeout,&app,[&] {
        switch(task++) {
        case 0:
            if(QPixmap(":/sixm/city.png").isNull() || QPixmap(":/sixm/logo.png").isNull() || !QFile::exists(":/sixm/theme.qss")) {
                bootstrap.stop(); QMessageBox::critical(&splash,"SixM startup error","Embedded launcher assets could not be loaded."); app.exit(1); return;
            }
            splash.setStage(1,"Visual resources loaded."); break;
        case 1: {
            sixm::AppSettings settings; const auto directory=settings.gameDirectory(); Q_UNUSED(directory);
            splash.setStage(2,"Local settings loaded. Preparing your launcher…"); break;
        }
        case 2:
            window=std::make_unique<sixm::MainWindow>();
            splash.setStage(3,"SixM is ready."); bootstrap.stop();
            QTimer::singleShot(300,&app,[&] {
                const QString capture=qEnvironmentVariable("SIXM_STARTUP_CAPTURE");
                if(check && !capture.isEmpty()) {
                    if(!QDir().mkpath(capture) || !splash.grab().save(capture+"/SixM-Startup.png")) {app.exit(2);return;}
                }
                window->show(); splash.close(); QApplication::setQuitOnLastWindowClosed(true);
                if(check) QTimer::singleShot(200,&app,[&,capture] {
                    if(!capture.isEmpty() && !window->grab().save(capture+"/SixM-Dashboard.png")) {app.exit(2);return;}
                    app.quit();
                });
            });
            break;
        }
    });
    bootstrap.start(); return app.exec();
}
