#pragma once
#include <QSettings>
#include <QString>

namespace sixm {
class AppSettings final {
public:
    AppSettings();
    QString gameDirectory() const;
    bool saveGameDirectory(const QString& path);
private:
    QSettings settings_;
};
}
