#pragma once
#include "AppSettings.h"
#include "NavigationBar.h"
#include <QMainWindow>
#include <QUrl>
class QLabel;
class QLineEdit;
class QStackedWidget;
namespace sixm {
class MasterClient;
class MainWindow final : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr,const QUrl& masterUrl=QUrl("http://127.0.0.1:5080"));
    void navigate(Page page);
    Page currentPage() const;
protected:
    bool nativeEvent(const QByteArray& eventType, void* message, qintptr* result) override;
private:
    QWidget* createHome();
    QWidget* createUnavailable(const QString& title, const QString& description);
    QWidget* createSettings();
    QWidget* createAbout();
    NavigationBar* navigation_{};
    QStackedWidget* pages_{};
    QLineEdit* directory_{};
    QLabel* settingsMessage_{};
    AppSettings settings_;
    MasterClient* master_{};
};
}
