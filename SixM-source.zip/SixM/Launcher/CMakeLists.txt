add_library(SixMLauncher STATIC
    MainWindow.cpp MainWindow.h NavigationBar.cpp NavigationBar.h HeroBanner.cpp HeroBanner.h
    Dashboard.cpp Dashboard.h SplashScreen.cpp SplashScreen.h
    MasterClient.cpp MasterClient.h AccountWidget.cpp AccountWidget.h
    AppSettings.cpp AppSettings.h Icons.h WindowChrome.h)
target_link_libraries(SixMLauncher PUBLIC Qt6::Widgets Qt6::Network)
target_include_directories(SixMLauncher PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_definitions(SixMLauncher PUBLIC SIXM_VERSION="${PROJECT_VERSION}" NOMINMAX WIN32_LEAN_AND_MEAN)
target_compile_options(SixMLauncher PRIVATE /W4 /permissive- /utf-8)
qt_add_executable(SixM WIN32 main.cpp assets.qrc SixM.rc)
target_link_libraries(SixM PRIVATE SixMLauncher)
target_compile_options(SixM PRIVATE /W4 /permissive- /utf-8)
get_target_property(_qmake Qt6::qmake IMPORTED_LOCATION)
get_filename_component(_qtTools "${_qmake}" DIRECTORY)
add_custom_command(TARGET SixM POST_BUILD
    COMMAND "${_qtTools}/windeployqt.exe" --release --no-translations --no-opengl-sw --no-compiler-runtime
        --no-system-d3d-compiler --no-system-dxc-compiler
        --skip-plugin-types generic,networkinformation "$<TARGET_FILE:SixM>"
    COMMAND ${CMAKE_COMMAND} -E copy_if_different "${CMAKE_CURRENT_SOURCE_DIR}/qt.conf" "$<TARGET_FILE_DIR:SixM>/qt.conf"
    VERBATIM)
install(TARGETS SixM RUNTIME DESTINATION .)
install(FILES qt.conf DESTINATION .)
