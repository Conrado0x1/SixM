#include "NavigationBar.h"
#include "Icons.h"
#include <QButtonGroup>
#include <QHBoxLayout>
#include <QLabel>
#include <QMouseEvent>
#include <QPushButton>
#include <QWindow>
namespace sixm {
NavigationBar::NavigationBar(QWidget* parent) : QFrame(parent) {
    setObjectName("navigationBar"); setFixedHeight(70);
    auto* row = new QHBoxLayout(this); row->setContentsMargins(24,12,20,12); row->setSpacing(8);
    auto* mark = new QLabel;
    mark->setPixmap(QPixmap(":/sixm/logo.png").copy(150,230,730,530).scaled(32,26,Qt::KeepAspectRatio,Qt::SmoothTransformation)); row->addWidget(mark);
    auto* brand = new QLabel("SIX<span style='color:#3a94ff'>M</span>"); brand->setObjectName("brand"); row->addWidget(brand); row->addSpacing(28);
    const QStringList names{"Home","Servers","Favorites","Settings","About"};
    const QStringList labels{"Discover","Servers","Favorites","Settings","Developers ↗"};
    auto* group = new QButtonGroup(this); group->setExclusive(true);
    for(int i=0;i<names.size();++i) {
        auto* b = new QPushButton(labels[i]); b->setObjectName("nav"+names[i]); b->setProperty("nav",true);
        b->setAccessibleName(names[i]); b->setCheckable(true); b->setCursor(Qt::PointingHandCursor); group->addButton(b,i);
        buttons_.append(b); row->addWidget(b);
        connect(b,&QPushButton::clicked,this,[this,i]{emit pageRequested(static_cast<Page>(i));});
    }
    row->addStretch();
    status_ = new QLabel("●  Checking API…"); status_->setObjectName("apiStatus"); row->addWidget(status_); row->addSpacing(12);
    row->addSpacing(10);
    const QStringList controls{"Minimize","Maximize or restore","Close"};
    for(int i=0;i<3;++i) {
        auto* b = new QPushButton; b->setIcon(chromeIcon(i)); b->setIconSize(QSize(15,15));
        b->setProperty("chrome",true); b->setFixedSize(34,34); b->setAccessibleName(controls[i]); row->addWidget(b);
        connect(b,&QPushButton::clicked,this,[this,i]{if(i==0) window()->showMinimized(); else if(i==1) toggleMaximize(); else window()->close();});
    }
    select(Page::Home);
}
void NavigationBar::select(Page page) {
    const int index=page==Page::History?0:static_cast<int>(page);
    buttons_.at(index)->setChecked(true);
}
void NavigationBar::setApiStatus(const QString& text,bool available) {
    status_->setText(text);
    status_->setStyleSheet(available?"color:#72cbb3":"color:#91a1ba");
}
void NavigationBar::toggleMaximize() { if(window()->isMaximized()) window()->showNormal(); else window()->showMaximized(); }
void NavigationBar::mousePressEvent(QMouseEvent* event) {
    if(event->button()==Qt::LeftButton && window()->windowHandle()) window()->windowHandle()->startSystemMove();
    QFrame::mousePressEvent(event);
}
void NavigationBar::mouseDoubleClickEvent(QMouseEvent* event) { if(event->button()==Qt::LeftButton) toggleMaximize(); }
}
