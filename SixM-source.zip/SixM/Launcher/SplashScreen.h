#pragma once
#include <QWidget>
class QLabel;
class QProgressBar;
namespace sixm {
class SplashScreen final : public QWidget {
public:
    explicit SplashScreen(QWidget* parent=nullptr);
    void setStage(int stage,const QString& message);
private:
    QProgressBar* progress_{};
    QLabel* message_{};
    QLabel* step_{};
};
}
