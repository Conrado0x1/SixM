#pragma once
#include <QIcon>
#include <QPainter>
#include <QPainterPath>

namespace sixm {
// Lucide minus, square and x: vendored SVG originals in Assets/Lucide.
// Draw their 24x24 paths directly to avoid a runtime SVG dependency.
inline QIcon chromeIcon(int control) {
    QPixmap image(48,48); image.fill(Qt::transparent);
    QPainter p(&image); p.setRenderHint(QPainter::Antialiasing); p.scale(2,2);
    p.setPen(QPen(QColor("#b7c3d4"),2,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin));
    p.setBrush(Qt::NoBrush);
    if(control==0) p.drawLine(5,12,19,12);
    else if(control==1) p.drawRoundedRect(QRectF(3,3,18,18),2,2);
    else {p.drawLine(18,6,6,18); p.drawLine(6,6,18,18);}
    p.end(); return QIcon(image);
}
enum class Symbol { Home, Servers, Star, Settings, Info, Person, Play, Folder, Bolt, Globe, Calendar, Chart };
inline QIcon icon(Symbol symbol, QColor color = QColor("#9badd0")) {
    QPixmap pixmap(48, 48);
    pixmap.fill(Qt::transparent);
    QPainter p(&pixmap);
    p.setRenderHint(QPainter::Antialiasing);
    p.scale(2, 2);
    p.setPen(QPen(color, 1.8, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    p.setBrush(color);
    QPainterPath path;
    switch (symbol) {
    case Symbol::Home:
        path.moveTo(2, 11); path.lineTo(12, 2); path.lineTo(22, 11); path.lineTo(19, 11);
        path.lineTo(19, 22); path.lineTo(14, 22); path.lineTo(14, 15); path.lineTo(9, 15);
        path.lineTo(9, 22); path.lineTo(5, 22); path.lineTo(5, 11); path.closeSubpath(); p.drawPath(path); break;
    case Symbol::Servers:
        for(int y : {3, 10, 17}) { p.drawRoundedRect(QRectF(3, y, 18, 4), 1, 1); p.setPen(QColor("#06112e")); p.drawPoint(6,y+2); p.setPen(QPen(color,1.8)); } break;
    case Symbol::Star:
        path.moveTo(12, 2); path.lineTo(15, 8); path.lineTo(22, 9); path.lineTo(17, 14); path.lineTo(18, 21);
        path.lineTo(12, 18); path.lineTo(6, 21); path.lineTo(7, 14); path.lineTo(2, 9); path.lineTo(9, 8); path.closeSubpath(); p.drawPath(path); break;
    case Symbol::Settings:
        for(int a=0;a<8;++a) { p.save(); p.translate(12,12); p.rotate(a*45); p.drawRect(QRectF(-2,-10,4,5)); p.restore(); }
        p.drawEllipse(QRectF(5,5,14,14)); p.setBrush(QColor("#07122b")); p.drawEllipse(QRectF(9,9,6,6)); break;
    case Symbol::Info:
        p.drawEllipse(QRectF(2,2,20,20)); p.setPen(QPen(QColor("#06112e"),2.2)); p.drawLine(12,11,12,17); p.drawPoint(12,7); break;
    case Symbol::Person:
        p.drawEllipse(QRectF(8,2,8,8)); p.drawRoundedRect(QRectF(4,13,16,9),5,5); break;
    case Symbol::Play:
        path.moveTo(6,3); path.lineTo(21,12); path.lineTo(6,21); path.closeSubpath(); p.drawPath(path); break;
    case Symbol::Folder:
        path.moveTo(2,7); path.lineTo(2,4); path.lineTo(10,4); path.lineTo(13,7); path.lineTo(22,7); path.lineTo(22,21); path.lineTo(2,21); path.closeSubpath(); p.drawPath(path); break;
    case Symbol::Bolt:
        path.moveTo(13,1); path.lineTo(4,14); path.lineTo(11,14); path.lineTo(9,23); path.lineTo(21,9); path.lineTo(13,9); path.closeSubpath(); p.drawPath(path); break;
    case Symbol::Globe:
        p.setBrush(Qt::NoBrush); p.drawEllipse(QRectF(2,2,20,20)); p.drawEllipse(QRectF(7,2,10,20)); p.drawLine(3,8,21,8); p.drawLine(3,16,21,16); break;
    case Symbol::Calendar:
        p.setBrush(Qt::NoBrush); p.drawRoundedRect(QRectF(3,5,18,17),2,2); p.drawLine(3,10,21,10); p.drawLine(8,2,8,7); p.drawLine(16,2,16,7);
        for(int x : {7,12,17}) for(int y : {14,18}) p.drawPoint(x,y); break;
    case Symbol::Chart:
        p.drawRoundedRect(QRectF(3,13,4,9),1,1); p.drawRoundedRect(QRectF(10,3,4,19),1,1); p.drawRoundedRect(QRectF(17,8,4,14),1,1); break;
    }
    p.end();
    return QIcon(pixmap);
}
}
