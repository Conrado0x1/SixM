#include "SplashScreen.h"
#include <QApplication>
#include <QLabel>
#include <QProgressBar>
#include <QScreen>
#include <QVBoxLayout>
namespace sixm {
SplashScreen::SplashScreen(QWidget* parent):QWidget(parent,Qt::SplashScreen|Qt::FramelessWindowHint) {
    setObjectName("startupScreen"); setFixedSize(440,460);
    setStyleSheet("QWidget#startupScreen {background:#111419; border:1px solid #2b3443; border-radius:10px;} QLabel {color:#8995a8; background:transparent; border:none; font-family:'Segoe UI';} QProgressBar {background:#080a0d; border:none; border-radius:2px; max-height:4px;} QProgressBar::chunk {background:#348bff; border-radius:2px;}");
    auto* layout=new QVBoxLayout(this); layout->setContentsMargins(30,26,30,28); layout->setSpacing(10);
    auto* caption=new QLabel("SIXM  /  LAUNCHER"); caption->setStyleSheet("font-size:11px; letter-spacing:2px; color:#99a8bf;"); layout->addWidget(caption);
    layout->addStretch();
    auto* logo=new QLabel; logo->setObjectName("startupLogo"); logo->setAlignment(Qt::AlignCenter);
    logo->setPixmap(QPixmap(":/sixm/logo.png").copy(150,230,730,530).scaled(166,128,Qt::KeepAspectRatio,Qt::SmoothTransformation)); layout->addWidget(logo);
    auto* brand=new QLabel("SIX<span style='color:#3c92ff'>M</span>"); brand->setAlignment(Qt::AlignCenter); brand->setStyleSheet("font-size:27px;font-weight:700;letter-spacing:6px;color:#f2f5fc;"); layout->addWidget(brand);
    auto* slogan=new QLabel("A new era of multiplayer."); slogan->setAlignment(Qt::AlignCenter); slogan->setStyleSheet("font-size:12px;color:#738198;"); layout->addWidget(slogan);
    layout->addStretch();
    step_=new QLabel; step_->setObjectName("startupStep"); step_->setStyleSheet("font-size:10px;letter-spacing:1px;color:#a9b6c9;"); layout->addWidget(step_);
    progress_=new QProgressBar; progress_->setObjectName("startupProgress"); progress_->setRange(0,3); progress_->setTextVisible(false); progress_->setFixedHeight(4); layout->addWidget(progress_);
    message_=new QLabel; message_->setObjectName("startupMessage"); message_->setStyleSheet("font-size:11px;"); layout->addWidget(message_);
    layout->addSpacing(8); auto* version=new QLabel("v" SIXM_VERSION "   ·   LOCAL STARTUP"); version->setStyleSheet("font-size:9px;color:#4e5c70;"); layout->addWidget(version);
    setStage(0,"Preparing SixM…");
    if(auto* screen=QApplication::primaryScreen()) move(screen->availableGeometry().center()-rect().center());
}
void SplashScreen::setStage(int stage,const QString& message) {
    const int completed=qBound(0,stage,3); progress_->setValue(completed);
    step_->setText(QString("INITIALIZING  ·  %1 / 3 TASKS COMPLETE").arg(completed)); message_->setText(message);
}
}
