#pragma once
#include <QWidget>
class QLabel;
class QLineEdit;
class QStackedWidget;
class QTabWidget;
namespace sixm {
class MasterClient;
class AccountWidget final : public QWidget {
    Q_OBJECT
public:
    explicit AccountWidget(MasterClient* client,QWidget* parent=nullptr);
private:
    void updateSession();
    MasterClient* client_;
    QStackedWidget* pages_;
    QTabWidget* forms_;
    QLabel* profile_;
    QLabel* message_;
    QLineEdit* loginEmail_;
    QLineEdit* loginPassword_;
    QLineEdit* registerName_;
    QLineEdit* registerEmail_;
    QLineEdit* registerPassword_;
};
}
