#include "AppSettings.h"
#include <QDir>

namespace sixm {
AppSettings::AppSettings()
    : settings_(QSettings::IniFormat, QSettings::UserScope, "SixM", "Launcher") {}
QString AppSettings::gameDirectory() const { return settings_.value("game/directory").toString(); }
bool AppSettings::saveGameDirectory(const QString& path) {
    if (!path.isEmpty() && !QDir(path).exists()) return false;
    settings_.setValue("game/directory", path.isEmpty() ? QString{} : QDir::cleanPath(path));
    settings_.sync();
    return settings_.status() == QSettings::NoError;
}
}
