#pragma once
#include <QWidget>
#include <QPainter>
namespace sixm {
class Background final : public QWidget {
public:
    explicit Background(QWidget* parent=nullptr):QWidget(parent) {setObjectName("root");}
protected:
    void paintEvent(QPaintEvent*) override {QPainter p(this); p.fillRect(rect(),QColor("#090b0e")); p.setPen(QColor("#252a33")); p.drawRect(rect().adjusted(0,0,-1,-1));}
};
}
