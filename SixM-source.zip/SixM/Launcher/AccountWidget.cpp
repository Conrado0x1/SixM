#include "AccountWidget.h"
#include "MasterClient.h"
#include <QFormLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QStackedWidget>
#include <QTabWidget>
#include <QVBoxLayout>

namespace {
QLineEdit* field(const QString& name,bool password=false) {
    auto* edit=new QLineEdit;edit->setObjectName(name);edit->setAccessibleName(name);
    edit->setMaxLength(password?128:254);if(password)edit->setEchoMode(QLineEdit::Password);return edit;
}
QPushButton* button(const QString& text,const QString& name) {
    auto* result=new QPushButton(text);result->setObjectName(name);result->setCursor(Qt::PointingHandCursor);return result;
}
}
namespace sixm {
AccountWidget::AccountWidget(MasterClient* client,QWidget* parent):QWidget(parent),client_(client) {
    setObjectName("accountPanel");setAttribute(Qt::WA_StyledBackground);
    auto* layout=new QVBoxLayout(this);layout->setContentsMargins(22,20,22,20);layout->setSpacing(14);
    auto* title=new QLabel("SixM account");title->setObjectName("cardTitle");layout->addWidget(title);
    auto* endpoint=new QLabel("Development API · "+client_->endpoint());endpoint->setObjectName("muted");layout->addWidget(endpoint);
    pages_=new QStackedWidget;layout->addWidget(pages_);
    forms_=new QTabWidget;pages_->addWidget(forms_);
    auto* login=new QWidget;auto* loginLayout=new QFormLayout(login);
    loginLayout->setContentsMargins(12,20,12,12);loginLayout->setSpacing(12);
    loginEmail_=field("loginEmail");loginPassword_=field("loginPassword",true);
    loginLayout->addRow("Email",loginEmail_);loginLayout->addRow("Password",loginPassword_);
    auto* signIn=button("Sign in","signInButton");signIn->setProperty("primary",true);loginLayout->addRow(signIn);
    forms_->addTab(login,"Sign in");
    auto* registration=new QWidget;auto* registerLayout=new QFormLayout(registration);
    registerLayout->setContentsMargins(12,20,12,12);registerLayout->setSpacing(12);
    registerName_=field("registerName");registerName_->setMaxLength(32);
    registerEmail_=field("registerEmail");registerPassword_=field("registerPassword",true);
    registerLayout->addRow("Display name",registerName_);registerLayout->addRow("Email",registerEmail_);registerLayout->addRow("Password",registerPassword_);
    auto* rules=new QLabel("12–128 characters, including uppercase, lowercase, a number and a symbol.");rules->setObjectName("muted");rules->setWordWrap(true);registerLayout->addRow(rules);
    auto* create=button("Create account","registerButton");create->setProperty("primary",true);registerLayout->addRow(create);
    forms_->addTab(registration,"Create account");
    auto* account=new QWidget;auto* accountLayout=new QVBoxLayout(account);accountLayout->setContentsMargins(0,0,0,0);
    profile_=new QLabel;profile_->setObjectName("accountProfile");profile_->setTextFormat(Qt::PlainText);profile_->setWordWrap(true);accountLayout->addWidget(profile_);
    auto* refresh=button("Renew session","refreshSessionButton");accountLayout->addWidget(refresh,0,Qt::AlignLeft);
    auto* signOut=button("Sign out","signOutButton");accountLayout->addWidget(signOut,0,Qt::AlignLeft);pages_->addWidget(account);
    auto* privacy=new QLabel("Sign in again after closing the launcher. Your password and session tokens are not saved to launcher settings.");privacy->setWordWrap(true);privacy->setObjectName("muted");layout->addWidget(privacy);
    message_=new QLabel;message_->setObjectName("accountMessage");message_->setTextFormat(Qt::PlainText);message_->setWordWrap(true);layout->addWidget(message_);
    auto* check=button("Check API connection","checkApiButton");layout->addWidget(check,0,Qt::AlignLeft);
    connect(check,&QPushButton::clicked,client_,&MasterClient::checkHealth);
    connect(signIn,&QPushButton::clicked,this,[this] {
        if(loginEmail_->text().trimmed().isEmpty() || loginPassword_->text().isEmpty()) {message_->setText("Enter your email and password.");return;}
        client_->signIn(loginEmail_->text().trimmed(),loginPassword_->text());
    });
    connect(loginPassword_,&QLineEdit::returnPressed,signIn,&QPushButton::click);
    connect(create,&QPushButton::clicked,this,[this] {
        if(registerEmail_->text().trimmed().isEmpty() || registerName_->text().trimmed().isEmpty() || registerPassword_->text().size()<12) {
            message_->setText("Enter your display name, email and a password of at least 12 characters.");return;
        }
        client_->registerAccount(registerEmail_->text().trimmed(),registerPassword_->text(),registerName_->text().trimmed());
    });
    connect(refresh,&QPushButton::clicked,client_,&MasterClient::refreshSession);
    connect(signOut,&QPushButton::clicked,client_,&MasterClient::signOut);
    connect(client_,&MasterClient::registered,this,[this] {loginEmail_->setText(registerEmail_->text());forms_->setCurrentIndex(0);});
    connect(client_,&MasterClient::sessionChanged,this,&AccountWidget::updateSession);
    connect(client_,&MasterClient::busyChanged,this,[this,signIn,create,refresh,signOut](bool busy) {
        for(auto* b:{signIn,create,refresh,signOut}) b->setEnabled(!busy);
        forms_->setEnabled(!busy);
        if(!busy) {loginPassword_->clear();registerPassword_->clear();}
    });
    connect(client_,&MasterClient::message,this,[this](const QString& text,bool error) {
        message_->setText(text);message_->setStyleSheet(error?"color:#e69797":"color:#8bbcf4");
    });
    updateSession();
}
void AccountWidget::updateSession() {
    pages_->setCurrentIndex(client_->signedIn()?1:0);
    const auto user=client_->profile();
    profile_->setText(QString("Signed in as %1\n%2\nEmail verification: %3")
        .arg(user.value("displayName").toString(),user.value("email").toString(),user.value("emailConfirmed").toBool()?"verified":"not verified (development account)"));
}
}
