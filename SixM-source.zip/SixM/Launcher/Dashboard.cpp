#include "Dashboard.h"
#include "HeroBanner.h"
#include "Icons.h"
#include <QLabel>
#include <QPainter>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>

namespace {
QLabel* label(const QString& value,const char* name="body") {
    auto* result=new QLabel(value); result->setObjectName(name); result->setWordWrap(true); return result;
}
QFrame* panel(const char* name,QVBoxLayout*& content) {
    auto* result=new QFrame; result->setObjectName(name); result->setProperty("card",true);
    content=new QVBoxLayout(result); content->setContentsMargins(22,20,22,20); content->setSpacing(12); return result;
}
QPushButton* button(const QString& title,const QString& name) {
    auto* result=new QPushButton(title); result->setObjectName(name); result->setCursor(Qt::PointingHandCursor); return result;
}
class Spotlight final : public QFrame {
public:
    explicit Spotlight(QWidget* parent=nullptr):QFrame(parent),city_(":/sixm/city.png") {setObjectName("spotlight"); setMinimumHeight(260);}
protected:
    void paintEvent(QPaintEvent*) override {
        QPainter p(this); p.drawPixmap(rect(),city_);
        QLinearGradient shade(0,0,width(),height()/2.0);
        shade.setColorAt(0,QColor(12,14,18,245)); shade.setColorAt(0.55,QColor(12,14,18,205)); shade.setColorAt(1,QColor(12,14,18,95)); p.fillRect(rect(),shade);
    }
private: QPixmap city_;
};
}
namespace sixm {
Dashboard::Dashboard(QWidget* parent):QWidget(parent) {
    setMinimumHeight(750);
    auto* shell=new QHBoxLayout(this); shell->setContentsMargins(0,0,0,0); shell->setSpacing(18);
    auto* main=new QVBoxLayout; main->setSpacing(14);
    auto* top=new QHBoxLayout; top->setSpacing(12);
    auto* hero=new HeroBanner; top->addWidget(hero,3);
    connect(hero,&HeroBanner::browseRequested,this,[this]{emit pageRequested(Page::Servers);});
    auto* shortcuts=new QVBoxLayout; shortcuts->setSpacing(12);
    const QStringList titles{"FAVORITES     ♡","HISTORY         ◷"};
    for(int i=0;i<2;++i) {
        auto* b=button(titles[i],i==0?"favoritesTile":"historyTile"); b->setProperty("tile",true); b->setMinimumWidth(190); shortcuts->addWidget(b,1);
        b->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
        connect(b,&QPushButton::clicked,this,[this,i]{emit pageRequested(i==0?Page::Favorites:Page::History);});
    }
    top->addLayout(shortcuts,1); main->addLayout(top,3);
    auto* section=new QHBoxLayout; section->addWidget(label("TOP SERVERS","eyebrow")); section->addStretch();
    auto* demoLabel=label("DEMONSTRATION DATA · NOT LIVE","demoBadge"); demoLabel->setFixedWidth(260); demoLabel->setAlignment(Qt::AlignRight|Qt::AlignVCenter); section->addWidget(demoLabel); main->addLayout(section);
    auto* feature=new Spotlight; auto* content=new QVBoxLayout(feature); content->setContentsMargins(26,24,26,22); content->setSpacing(8);
    auto* headline=new QHBoxLayout;
    auto* mark=new QLabel; mark->setPixmap(QPixmap(":/sixm/logo.png").copy(150,230,730,530).scaled(60,48,Qt::KeepAspectRatio,Qt::SmoothTransformation)); headline->addWidget(mark); headline->addSpacing(14);
    auto* names=new QVBoxLayout; names->setSpacing(6); names->addWidget(label("VICE CITY ROLEPLAY","spotlightTitle")); names->addWidget(label("Your city. Your people. Your story.","body")); headline->addLayout(names,1); content->addLayout(headline);
    content->addWidget(label("A community built around the stories you create.\nRoleplay · Economy · Custom experiences","spotlightDescription"));
    content->addWidget(label("◉  89 / 200  ·  DEMO SERVER","muted")); content->addStretch();
    auto* bottom=new QHBoxLayout; auto* connectButton=button("Connect   ↗","demoConnect0"); connectButton->setProperty("outline",true); bottom->addWidget(connectButton);
    auto* favorite=button("♡","favoritePreview"); favorite->setProperty("link",true); bottom->addWidget(favorite); bottom->addStretch();
    bottom->addWidget(label("ROLEPLAY     ECONOMY     FREEROAM","tag")); content->addLayout(bottom);
    connect(connectButton,&QPushButton::clicked,this,[this]{emit pageRequested(Page::Servers);});
    connect(favorite,&QPushButton::clicked,this,[this]{emit pageRequested(Page::Favorites);});
    main->addWidget(feature,4);
    auto* strip=new QHBoxLayout; auto* notice=label("SIXM  /  A NEW ERA OF MULTIPLAYER","communityStrip"); strip->addWidget(notice,2);
    for(const QString& title:{"RP","RACE","WORLD","LUA","SDK"}) { auto* tag=label(title,"communityChip"); tag->setAlignment(Qt::AlignCenter); strip->addWidget(tag); }
    main->addLayout(strip);
    auto* lower=new QHBoxLayout; lower->setSpacing(14);
    QVBoxLayout* featuredLayout; auto* featured=panel("featuredCommunity",featuredLayout);
    featuredLayout->addWidget(label("FEATURED COMMUNITY","eyebrow")); featuredLayout->addWidget(label("Make room for your world.","cardTitle")); featuredLayout->addWidget(label("Community spotlight · Demonstration","muted")); lower->addWidget(featured,2);
    QVBoxLayout* createLayout; auto* create=panel("createServer",createLayout);
    auto* createButton=button("CREATE A SERVER     ↗","createServerButton"); createButton->setProperty("link",true); createLayout->addWidget(createButton); createLayout->addWidget(label("Tools for the next generation of communities.\nServer tools are a future milestone.","muted")); lower->addWidget(create,1);
    connect(createButton,&QPushButton::clicked,this,[this]{emit pageRequested(Page::About);}); main->addLayout(lower,2);
    auto* links=new QHBoxLayout;
    auto* settings=button("LAUNCHER SETTINGS    ↗","configureButton"); auto* about=button("ABOUT SIXM    ↗","aboutBuildButton"); settings->setProperty("bottomTile",true); about->setProperty("bottomTile",true); links->addWidget(settings); links->addWidget(about);
    connect(settings,&QPushButton::clicked,this,[this]{emit pageRequested(Page::Settings);}); connect(about,&QPushButton::clicked,this,[this]{emit pageRequested(Page::About);}); main->addLayout(links);
    shell->addLayout(main,4);
    QVBoxLayout* feed; auto* news=panel("developmentFeed",feed); news->setMinimumWidth(270); news->setMaximumWidth(340);
    feed->addWidget(label("SIXM DEVELOPMENT FEED","eyebrow")); feed->addSpacing(6);
    feed->addWidget(label("SixM  /  v" SIXM_VERSION,"feedAuthor")); feed->addWidget(label("Launcher + identity","feedTitle"));
    feed->addWidget(label("SixM Master is now connected to the launcher. Open Settings to create an account, sign in and manage your session.","feedBody"));
    auto* image=new QLabel; image->setPixmap(QPixmap(":/sixm/city.png").scaled(280,140,Qt::IgnoreAspectRatio,Qt::SmoothTransformation)); image->setScaledContents(true); image->setMaximumHeight(155); feed->addWidget(image);
    feed->addWidget(label("LOCAL PROJECT UPDATE · NO REMOTE FEED","demoBadge")); feed->addSpacing(20);
    feed->addWidget(label("Built for creators.","feedTitle")); feed->addWidget(label("Dedicated servers, resources and Lua scripting are on the roadmap. This build focuses exclusively on the launcher foundation.","feedBody"));
    auto* docs=button("Explore the project   ↗","projectInfoButton"); docs->setProperty("link",true); feed->addWidget(docs,0,Qt::AlignLeft); connect(docs,&QPushButton::clicked,this,[this]{emit pageRequested(Page::About);});
    feed->addStretch(); feed->addWidget(label("INDEPENDENT BY DESIGN","eyebrow")); feed->addWidget(label("Not affiliated with Rockstar Games.\nNo game integration is included.","muted")); shell->addWidget(news,1);
}
}
