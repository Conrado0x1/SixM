#include "MainWindow.h"
#include "HeroBanner.h"
#include "Icons.h"
#include "WindowChrome.h"
#include "Dashboard.h"
#include "MasterClient.h"
#include "AccountWidget.h"
#include <QApplication>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFrame>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QScrollArea>
#include <QStackedWidget>
#include <QUrl>
#include <QVBoxLayout>
#include <Windows.h>

namespace {
QLabel* text(const QString& value, const char* style = "body") {
    auto* label = new QLabel(value);
    label->setObjectName(style);
    label->setWordWrap(true);
    label->setTextInteractionFlags(Qt::TextSelectableByMouse);
    return label;
}
QFrame* card(const QString& title, QVBoxLayout*& layout, sixm::Symbol symbol = sixm::Symbol::Info) {
    auto* frame = new QFrame;
    frame->setProperty("card", true);
    layout = new QVBoxLayout(frame);
    layout->setContentsMargins(20, 18, 20, 18);
    layout->setSpacing(10);
    auto* heading = new QHBoxLayout;
    auto* image = new QLabel;
    image->setPixmap(sixm::icon(symbol).pixmap(25,25));
    heading->addWidget(image);
    heading->addSpacing(6);
    heading->addWidget(text(title,"cardTitle"),1);
    layout->addLayout(heading);
    return frame;
}
QPushButton* action(const QString& title, const QString& name) {
    auto* button = new QPushButton(title);
    button->setObjectName(name);
    button->setCursor(Qt::PointingHandCursor);
    button->setMinimumHeight(42);
    return button;
}
QWidget* scrollable(QWidget* content) {
    auto* scroll = new QScrollArea;
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setWidget(content);
    return scroll;
}
}

namespace sixm {
MainWindow::MainWindow(QWidget* parent,const QUrl& masterUrl) : QMainWindow(parent) {
    master_=new MasterClient(masterUrl,this);
    setWindowTitle("SixM — Launcher v" SIXM_VERSION);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    setAttribute(Qt::WA_TranslucentBackground);
    setMinimumSize(1200,780); resize(1440,900);
    QFile style(":/sixm/theme.qss");
    if(style.open(QIODevice::ReadOnly)) setStyleSheet(QString::fromUtf8(style.readAll()));
    auto* root = new Background;
    auto* outer = new QVBoxLayout(root); outer->setContentsMargins(1,1,1,1); outer->setSpacing(0);
    navigation_ = new NavigationBar; outer->addWidget(navigation_);
    auto* shell = new QHBoxLayout; shell->setContentsMargins(0,8,0,0); shell->setSpacing(0);
    
    auto* workspace = new QWidget;
    auto* layout = new QVBoxLayout(workspace); layout->setContentsMargins(18,0,18,12); layout->setSpacing(16);
    pages_ = new QStackedWidget; pages_->setObjectName("pages");
    pages_->addWidget(scrollable(createHome()));
    pages_->addWidget(scrollable(createUnavailable("Your next world starts here.","Server discovery is planned for v0.3.0. The dashboard servers are demonstration entries. No live servers or game connection are available.")));
    pages_->addWidget(scrollable(createUnavailable("Your favorite communities.","Favorites will be available with the live server browser. Dashboard entries are demonstrations only.")));
    pages_->addWidget(scrollable(createSettings()));
    pages_->addWidget(scrollable(createAbout()));
    pages_->addWidget(scrollable(createUnavailable("Connection history", "No connections have been made. History tracking will be available when multiplayer sessions are implemented.")));
    layout->addWidget(pages_,1);
    auto* footer = new QFrame; footer->setObjectName("statusStrip"); footer->setFixedHeight(28);
    auto* statusRow = new QHBoxLayout(footer); statusRow->setContentsMargins(0,0,0,0);
    auto* info = new QLabel; info->setPixmap(icon(Symbol::Info,QColor("#2784ff")).pixmap(22,22)); statusRow->addWidget(info);
    auto* connectionStatus=text("Checking SixM Master · Server listings are demonstration data.","footer");
    statusRow->addWidget(connectionStatus,1);
    statusRow->addWidget(text("v" SIXM_VERSION,"muted"));
    layout->addWidget(footer);
    shell->addWidget(workspace,1); outer->addLayout(shell,1);
    setCentralWidget(root);
    connect(navigation_,&NavigationBar::pageRequested,this,&MainWindow::navigate);
    connect(master_,&MasterClient::statusChanged,this,[this,connectionStatus](MasterClient::Status status) {
        const bool online=status==MasterClient::Status::Online;
        navigation_->setApiStatus(online?"●  API online":"●  API unavailable",online);
        connectionStatus->setText(online?"SixM Master connected · Sign in through Settings · Multiplayer servers remain demonstrations.":
            "SixM Master unavailable · Start the local API to sign in · Multiplayer servers are demonstrations.");
    });
}
void MainWindow::navigate(Page page) {
    pages_->setCurrentIndex(static_cast<int>(page)); navigation_->select(page);
}
Page MainWindow::currentPage() const { return static_cast<Page>(pages_->currentIndex()); }
bool MainWindow::nativeEvent(const QByteArray& eventType, void* message, qintptr* result) {
    const auto* msg = static_cast<MSG*>(message);
    if(msg->message == WM_NCHITTEST && !isMaximized()) {
        RECT bounds{};
        if(GetWindowRect(reinterpret_cast<HWND>(winId()),&bounds)) {
            const int x = static_cast<short>(LOWORD(msg->lParam));
            const int y = static_cast<short>(HIWORD(msg->lParam));
            const bool left = x < bounds.left+7, right = x >= bounds.right-7;
            const bool top = y < bounds.top+7, bottom = y >= bounds.bottom-7;
            if(top && left) *result = HTTOPLEFT;
            else if(top && right) *result = HTTOPRIGHT;
            else if(bottom && left) *result = HTBOTTOMLEFT;
            else if(bottom && right) *result = HTBOTTOMRIGHT;
            else if(left) *result = HTLEFT;
            else if(right) *result = HTRIGHT;
            else if(top) *result = HTTOP;
            else if(bottom) *result = HTBOTTOM;
            else return QMainWindow::nativeEvent(eventType,message,result);
            return true;
        }
    }
    return QMainWindow::nativeEvent(eventType,message,result);
}
QWidget* MainWindow::createHome() {
    auto* dashboard = new Dashboard;
    connect(dashboard,&Dashboard::pageRequested,this,&MainWindow::navigate);
    return dashboard;
}
QWidget* MainWindow::createUnavailable(const QString& title, const QString& description) {
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 0, 8, 0);
    QVBoxLayout* content;
    auto* frame = card("COMING IN A FUTURE MILESTONE", content);
    content->addSpacing(36);
    content->addWidget(text(title, "welcome"));
    content->addWidget(text(description));
    content->addSpacing(18);
    auto* connectButton = action("Connect — unavailable", "connectUnavailable");
    connectButton->setEnabled(false);
    connectButton->setToolTip("Networking and GTA VI integration are not implemented in v0.1.0.");
    content->addWidget(connectButton, 0, Qt::AlignLeft);
    content->addSpacing(36);
    layout->addWidget(frame);
    layout->addStretch();
    return page;
}
QWidget* MainWindow::createSettings() {
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 0, 8, 0);
    layout->addWidget(new AccountWidget(master_));
    QVBoxLayout* content;
    auto* frame = card("Game directory", content);
    content->addWidget(text("Save a local directory for future integration. This setting does not validate a GTA VI installation or launch the game."));
    auto* row = new QHBoxLayout;
    directory_ = new QLineEdit(settings_.gameDirectory());
    directory_->setObjectName("gameDirectory");
    directory_->setPlaceholderText("No directory selected");
    directory_->setAccessibleName("Game directory");
    row->addWidget(directory_, 1);
    auto* browse = action("Browse…", "browseDirectoryButton");
    row->addWidget(browse);
    content->addLayout(row);
    auto* save = action("Save directory", "saveDirectoryButton");
    save->setProperty("primary", true);
    content->addWidget(save, 0, Qt::AlignLeft);
    settingsMessage_ = text("Stored locally in your Windows user profile.", "settingsMessage");
    content->addWidget(settingsMessage_);
    connect(browse, &QPushButton::clicked, this, [this] {
        const QString path = QFileDialog::getExistingDirectory(this, "Select game directory", directory_->text());
        if (!path.isEmpty()) directory_->setText(QDir::toNativeSeparators(path));
    });
    connect(save, &QPushButton::clicked, this, [this] {
        const QString path = QDir::fromNativeSeparators(directory_->text().trimmed());
        if (!path.isEmpty() && !QDir(path).exists()) {
            settingsMessage_->setText("Directory not found. Select an existing folder.");
            return;
        }
        settingsMessage_->setText(settings_.saveGameDirectory(path)
            ? "Directory saved locally. Game integration remains unavailable."
            : "Could not save settings. Check your user profile permissions.");
    });
    layout->addWidget(frame);
    QVBoxLayout* details;
    auto* future = card("Launcher preferences", details);
    details->addWidget(text("Appearance: Navy / Electric blue\nInterface language: English\nUpdates: Manual development build"));
    details->addWidget(text("Language selection, automatic startup and verified updates are planned. No updater or background service is running.", "muted"));
    layout->addWidget(future);
    layout->addStretch();
    return page;
}
QWidget* MainWindow::createAbout() {
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 0, 8, 0);
    QVBoxLayout* content;
    auto* frame = card("SixM  /  v" SIXM_VERSION, content);
    content->addWidget(text("A new era of multiplayer.", "welcome"));
    content->addWidget(text("Independent GTA VI Multiplayer Framework", "sectionTitle"));
    content->addWidget(text("v" SIXM_VERSION " — Master connection and account testing\nBuilt with C++20 and Qt 6 Widgets for Windows x64."));
    content->addWidget(text("This build connects to SixM Master for account registration, sign-in and session management. Live multiplayer discovery, verified updates and game integration are not implemented."));
    content->addWidget(text("SixM is an independent project and is not affiliated with or endorsed by Rockstar Games or Take-Two Interactive. No proprietary game files are included.", "muted"));
    auto* qt = action("About Qt", "aboutQtButton");
    content->addWidget(qt, 0, Qt::AlignLeft);
    connect(qt, &QPushButton::clicked, qApp, &QApplication::aboutQt);
    layout->addWidget(frame);
    layout->addStretch();
    return page;
}
}
