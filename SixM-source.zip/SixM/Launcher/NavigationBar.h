#pragma once
#include <QFrame>
#include <QList>
class QPushButton;
class QLabel;
namespace sixm {
enum class Page { Home, Servers, Favorites, Settings, About, History };
class NavigationBar final : public QFrame {
    Q_OBJECT
public:
    explicit NavigationBar(QWidget* parent=nullptr);
    void select(Page page);
    void setApiStatus(const QString& text,bool available);
signals:
    void pageRequested(sixm::Page page);
protected:
    void mousePressEvent(QMouseEvent* event) override;
    void mouseDoubleClickEvent(QMouseEvent* event) override;
private:
    void toggleMaximize();
    QList<QPushButton*> buttons_;
    QLabel* status_{};
};
}
