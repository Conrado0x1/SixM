#pragma once
#include "NavigationBar.h"
#include <QWidget>
namespace sixm {
class Dashboard final : public QWidget {
    Q_OBJECT
public:
    explicit Dashboard(QWidget* parent=nullptr);
signals:
    void pageRequested(sixm::Page page);
};
}
