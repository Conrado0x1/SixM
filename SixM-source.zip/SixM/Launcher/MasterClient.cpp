#include "MasterClient.h"
#include <QHostAddress>
#include <QJsonDocument>
#include <QNetworkReply>
#include <QNetworkRequest>

namespace sixm {
MasterClient::MasterClient(const QUrl& baseUrl,QObject* parent):QObject(parent),base_(baseUrl) {
    const QHostAddress address(base_.host());
    const bool local=address.isLoopback() || base_.host().compare("localhost",Qt::CaseInsensitive)==0;
    if(!base_.isValid() || !base_.userInfo().isEmpty() || base_.hasQuery() || base_.hasFragment()
       || (base_.scheme()!="https" && !(base_.scheme()=="http" && local))) base_=QUrl();
    healthTimer_.setInterval(10000);
    connect(&healthTimer_,&QTimer::timeout,this,&MasterClient::checkHealth);
    refreshTimer_.setSingleShot(true);
    connect(&refreshTimer_,&QTimer::timeout,this,&MasterClient::refreshSession);
    healthTimer_.start();
    QTimer::singleShot(0,this,&MasterClient::checkHealth);
}
MasterClient::~MasterClient() {
    healthTimer_.stop();refreshTimer_.stop();
    for(auto* reply:network_.findChildren<QNetworkReply*>()) {
        QObject::disconnect(reply,nullptr,this,nullptr);reply->abort();
    }
    access_.fill('\0');refresh_.fill(QChar('\0'));
}
void MasterClient::setBusy(bool value) {busy_=value; emit busyChanged(value);}
void MasterClient::request(const QString& path,const QJsonObject& body,bool post,bool authenticated,Callback callback) {
    if(base_.isEmpty()) {callback(0,{});return;}
    QNetworkRequest request(base_.resolved(QUrl(path)));
    request.setTransferTimeout(5000);
    request.setAttribute(QNetworkRequest::RedirectPolicyAttribute,QNetworkRequest::ManualRedirectPolicy);
    request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    if(authenticated) request.setRawHeader("Authorization","Bearer "+access_);
    auto* reply=post?network_.post(request,QJsonDocument(body).toJson(QJsonDocument::Compact)):network_.get(request);
    connect(reply,&QNetworkReply::finished,this,[reply,callback=std::move(callback)] {
        const int code=reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        const auto bytes=reply->read(256*1024);
        const auto json=QJsonDocument::fromJson(bytes).object();
        reply->deleteLater(); callback(code,json);
    });
}
void MasterClient::checkHealth() {
    if(healthPending_) return;
    healthPending_=true;
    request("/health/ready",{},false,false,[this](int code,const QJsonObject& json) {
        healthPending_=false;
        status_=code==200 && json.value("status").toString()=="ready"?Status::Online:Status::Unavailable;
        emit statusChanged(status_);
    });
}
void MasterClient::registerAccount(const QString& email,const QString& password,const QString& name) {
    if(busy_) return;
    setBusy(true);
    request("/v1/auth/register",{{"email",email},{"password",password},{"displayName",name}},true,false,
        [this](int code,const QJsonObject&) {
        setBusy(false);
        if(code==201) {emit message("Account created. Sign in with your email and password.",false);emit registered();}
        else emit message(code==0?"Could not reach SixM Master. Keep the API running.":
            code==429?"Too many attempts. Please try again later.":
            "Registration rejected. Check the password rules or sign in if this account already exists.",true);
    });
}
bool MasterClient::setTokens(const QJsonObject& json) {
    const auto access=json.value("accessToken").toString();
    const auto refresh=json.value("refreshToken").toString();
    const int seconds=json.value("expiresIn").toInt();
    if(access.size()!=43 || refresh.size()!=43 || seconds<=0 || seconds>900) return false;
    access_=access.toUtf8(); refresh_=refresh;
    refreshTimer_.start(qMax(1,seconds-30)*1000);
    return true;
}
void MasterClient::clearSession() {
    access_.fill('\0'); access_.clear(); refresh_.fill(QChar('\0')); refresh_.clear();
    profile_={}; refreshTimer_.stop(); emit sessionChanged();
}
void MasterClient::fetchProfile() {
    request("/v1/me",{},false,true,[this](int code,const QJsonObject& json) {
        setBusy(false);
        if(code==200 && !json.value("id").toString().isEmpty()) {
            profile_=json; emit sessionChanged(); emit message("Signed in to SixM Master.",false);
        } else {clearSession();emit message("The session could not be verified. Please sign in again.",true);}
    });
}
void MasterClient::signIn(const QString& email,const QString& password) {
    if(busy_) return;
    setBusy(true);
    request("/v1/auth/login",{{"email",email},{"password",password}},true,false,
        [this](int code,const QJsonObject& json) {
        if(code==200 && setTokens(json)) {fetchProfile();return;}
        setBusy(false);
        emit message(code==0?"Could not reach SixM Master. Keep the API running.":
            code==429?"Too many attempts. Please try again later.":"Sign-in failed. Check your credentials or try again after the account lockout expires.",true);
    });
}
void MasterClient::refreshSession() {
    if(!signedIn()) return;
    if(busy_) {refreshTimer_.start(1000);return;}
    setBusy(true);
    request("/v1/auth/refresh",{{"refreshToken",refresh_}},true,false,
        [this](int code,const QJsonObject& json) {
        setBusy(false);
        if(code==200 && setTokens(json)) emit message("Session renewed successfully.",false);
        else if(code==401 || code==200) {clearSession();emit message("Your session expired. Please sign in again.",true);}
        else {refreshTimer_.start(10000);emit message("Could not renew the session. Retrying shortly.",true);}
    });
}
void MasterClient::signOut() {
    if(busy_ || !signedIn()) return;
    setBusy(true);
    request("/v1/auth/logout",{},true,true,[this](int code,const QJsonObject&) {
        setBusy(false);
        emit message(code==204?"Signed out. The server session was revoked.":
            "Signed out locally. The API could not confirm server revocation.",code!=204);
    });
    clearSession();
}
}
