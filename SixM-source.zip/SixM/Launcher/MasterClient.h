#pragma once
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QObject>
#include <QTimer>
#include <QUrl>
#include <functional>

namespace sixm {
class MasterClient final : public QObject {
    Q_OBJECT
public:
    enum class Status { Checking, Online, Unavailable };
    Q_ENUM(Status)
    explicit MasterClient(const QUrl& baseUrl, QObject* parent=nullptr);
    ~MasterClient() override;
    Status status() const { return status_; }
    bool signedIn() const { return !access_.isEmpty(); }
    bool busy() const { return busy_; }
    QJsonObject profile() const { return profile_; }
    QString endpoint() const { return base_.toString(); }
    void checkHealth();
    void registerAccount(const QString& email,const QString& password,const QString& displayName);
    void signIn(const QString& email,const QString& password);
    void refreshSession();
    void signOut();
signals:
    void statusChanged(sixm::MasterClient::Status status);
    void sessionChanged();
    void busyChanged(bool busy);
    void message(const QString& text,bool error);
    void registered();
private:
    using Callback=std::function<void(int,const QJsonObject&)>;
    void request(const QString& path,const QJsonObject& body,bool post,bool authenticated,Callback callback);
    bool setTokens(const QJsonObject& json);
    void fetchProfile();
    void clearSession();
    void setBusy(bool value);
    QUrl base_;
    QNetworkAccessManager network_;
    QTimer healthTimer_;
    QTimer refreshTimer_;
    Status status_{Status::Checking};
    bool busy_{};
    bool healthPending_{};
    QByteArray access_;
    QString refresh_;
    QJsonObject profile_;
};
}
