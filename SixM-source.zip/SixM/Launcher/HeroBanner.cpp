#include "HeroBanner.h"
#include <QLabel>
#include <QPainter>
#include <QPushButton>
#include <QVBoxLayout>
namespace sixm {
HeroBanner::HeroBanner(QWidget* parent):QWidget(parent),background_(":/sixm/city.png") {
    setObjectName("hero"); setMinimumHeight(190);
    auto* layout=new QVBoxLayout(this); layout->setContentsMargins(24,22,24,18); layout->setSpacing(8);
    auto* eyebrow=new QLabel("WELCOME TO SIXM"); eyebrow->setObjectName("eyebrow"); layout->addWidget(eyebrow);
    auto* title=new QLabel("A new era of multiplayer."); title->setObjectName("heroTitle"); title->setWordWrap(true); layout->addWidget(title);
    layout->addStretch();
    auto* browse=new QPushButton("BROWSE SERVERS     ▸"); browse->setObjectName("exploreButton"); browse->setProperty("link",true); browse->setCursor(Qt::PointingHandCursor);
    layout->addWidget(browse,0,Qt::AlignLeft); connect(browse,&QPushButton::clicked,this,&HeroBanner::browseRequested);
}
void HeroBanner::paintEvent(QPaintEvent*) {
    QPainter p(this); p.drawPixmap(rect(),background_);
    QLinearGradient shade(0,0,width(),0); shade.setColorAt(0,QColor(15,18,23,245)); shade.setColorAt(1,QColor(12,19,32,115)); p.fillRect(rect(),shade);
}
}
