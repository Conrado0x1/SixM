#pragma once
#include <QWidget>
#include <QPixmap>
namespace sixm {
class HeroBanner final : public QWidget {
    Q_OBJECT
public:
    explicit HeroBanner(QWidget* parent = nullptr);
signals:
    void browseRequested();
protected:
    void paintEvent(QPaintEvent*) override;
private:
    QPixmap background_;
};
}
