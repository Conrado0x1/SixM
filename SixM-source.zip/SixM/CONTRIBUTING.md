# Contributing to SixM

Contributions are welcome: bug reports, fixes, documentation, tests, and new features that fit the project roadmap.

1. Describe the problem or proposed improvement in an issue or pull request.
2. Keep changes focused and preserve the module boundaries.
3. Preserve the SixM framework name, original credits, and project identity.
4. Identify publicly distributed forks as unofficial and describe your changes.
5. Include appropriate validation and avoid presenting planned features as complete.
6. Never submit credentials, tokens, proprietary game files, or protection-bypass code.

Names for individual servers, resources, scripts, and user content remain configurable. Ordinary internal refactoring is allowed.

By intentionally submitting a contribution for inclusion, you offer it under the [SixM Community Source License](LICENSE) and confirm that you have the necessary rights. You retain copyright in your own original contribution. Acceptance remains the maintainers' decision.
